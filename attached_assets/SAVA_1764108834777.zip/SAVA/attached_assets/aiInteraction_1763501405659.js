// aiInteraction.js

// Function to get predictions from OpenAI API
export async function getPredictions(prompt, model = 'gpt-3.5-turbo') {
    const apiKey = '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';  // Replace with your OpenAI API key
    const url = 'https://api.openai.com/v1/chat/completions';

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: model,
                messages: [
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens: 4000
            })
        });

        if (!response.ok) {
            console.error(`API request failed with status: ${response.status}`);
            return ["Sorry, I couldn't generate a suggestion. Please try again."];
        }

        const data = await response.json();

        if (data.choices && data.choices.length > 0) {
            return data.choices[0].message.content.split('\n').filter(line => line.trim() !== '');
        } else {
            console.error("No choices found in the response:", JSON.stringify(data, null, 2));
            return ["Sorry, I couldn't generate a suggestion. Please try again."];
        }
    } catch (error) {
        console.error("Error fetching predictions:", error);
        return ["An error occurred while fetching predictions. Please check your API key and network connection."];
    }
}
