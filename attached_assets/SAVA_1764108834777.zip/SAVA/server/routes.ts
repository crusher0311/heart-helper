import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  generateSalesScript,
  generateConcernFollowUpQuestions,
  reviewConcernConversation,
  cleanConcernConversation
} from "./openai";
import { tekmetricClient } from "./tekmetric";
import {
  insertTrainingExampleSchema,
  insertObjectionResponseSchema,
  generateScriptRequestSchema,
  incomingCallerRequestSchema,
  insertConversationSchema,
  generateConcernQuestionsRequestSchema,
  reviewConcernConversationRequestSchema,
  cleanConversationRequestSchema,
} from "@shared/schema";
import { z } from "zod";
import archiver from "archiver";
import path from "path";
import fs from "fs";

export async function registerRoutes(app: Express): Promise<Server> {
  const DEFAULT_ORG_ID = "default-org";

  // Middleware to get current organization (in real app, this would come from auth/session)
  // For MVP, we use the default organization
  const getCurrentOrg = (req: any): string => {
    // TODO: In production, extract from authenticated session
    // return req.session.organizationId || DEFAULT_ORG_ID;
    return DEFAULT_ORG_ID;
  };

  // Ensure default organization exists
  const ensureDefaultOrg = async () => {
    try {
      const existing = await storage.getOrganization(DEFAULT_ORG_ID);
      if (!existing) {
        // Insert with specific ID using raw SQL to avoid UUID generation
        await storage.createOrganization({
          name: "Default Organization",
        });
      }
    } catch (error) {
      console.log("Default organization setup:", error);
    }
  };
  await ensureDefaultOrg();

  // Organization Settings
  app.get("/api/organizations/current", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const organization = await storage.getOrganization(orgId);
      
      if (!organization) {
        return res.status(404).json({ error: "Organization not found" });
      }
      
      res.json(organization);
    } catch (error) {
      console.error("Error fetching organization:", error);
      res.status(500).json({ error: "Failed to fetch organization" });
    }
  });

  app.patch("/api/organizations/current", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const updateSchema = z.object({
        name: z.string().optional(),
        phoneAnswerScript: z.string().optional(),
      });
      
      const data = updateSchema.parse(req.body);
      const updated = await storage.updateOrganization(orgId, data);
      
      if (!updated) {
        return res.status(404).json({ error: "Organization not found" });
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating organization:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update organization" });
    }
  });

  // Training Examples
  app.get("/api/training", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const examples = await storage.getTrainingExamples(orgId);
      res.json(examples);
    } catch (error) {
      console.error("Error fetching training examples:", error);
      res.status(500).json({ error: "Failed to fetch training examples" });
    }
  });

  app.post("/api/training", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const data = insertTrainingExampleSchema.parse(req.body);
      
      // Server injects organizationId from authenticated session
      const example = await storage.createTrainingExample(data, orgId);
      
      res.json(example);
    } catch (error) {
      console.error("Error creating training example:", error);
      if (error instanceof Error && error.name === "ZodError") {
        res.status(400).json({ error: "Invalid training example data", details: error.message });
      } else {
        res.status(400).json({ error: "Invalid training example data" });
      }
    }
  });

  app.delete("/api/training/:id", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      // Enforce tenant scoping - can only delete own organization's data
      await storage.deleteTrainingExample(req.params.id, orgId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting training example:", error);
      res.status(500).json({ error: "Failed to delete training example" });
    }
  });

  // Objection Responses
  app.get("/api/objections", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const objections = await storage.getObjectionResponses(orgId);
      res.json(objections);
    } catch (error) {
      console.error("Error fetching objection responses:", error);
      res.status(500).json({ error: "Failed to fetch objection responses" });
    }
  });

  app.post("/api/objections", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const data = insertObjectionResponseSchema.parse(req.body);
      
      // Server injects organizationId from authenticated session
      const objection = await storage.createObjectionResponse(data, orgId);
      
      res.json(objection);
    } catch (error) {
      console.error("Error creating objection response:", error);
      if (error instanceof Error && error.name === "ZodError") {
        res.status(400).json({ error: "Invalid objection response data", details: error.message });
      } else {
        res.status(400).json({ error: "Invalid objection response data" });
      }
    }
  });

  app.delete("/api/objections/:id", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      // Enforce tenant scoping - can only delete own organization's data
      await storage.deleteObjectionResponse(req.params.id, orgId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting objection response:", error);
      res.status(500).json({ error: "Failed to delete objection response" });
    }
  });

  // Script Generation
  app.post("/api/scripts/generate", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      
      // Log incoming request for debugging
      console.log('[Script Generation] Request body:', JSON.stringify(req.body, null, 2));
      console.log('[Script Generation] Repair order count:', req.body.repairOrders?.length || 0);
      console.log('[Script Generation] Prices from Tekmetric:', req.body.repairOrders?.map((ro: any) => `${ro.service}: $${ro.price}`).join(', '));
      
      // Validate request with Zod schema
      const validationResult = generateScriptRequestSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        console.error('[Script Generation] Validation failed:', validationResult.error.errors);
        return res.status(400).json({ 
          error: "Invalid request data",
          details: validationResult.error.errors.map(e => ({
            path: e.path.join('.'),
            message: e.message,
          })),
        });
      }
      
      const request = validationResult.data;
      
      // Get training examples for current organization (ignore client-supplied organizationId)
      const trainingExamples = await storage.getTrainingExamples(orgId);
      
      // Generate script using OpenAI
      const script = await generateSalesScript(
        { ...request, organizationId: orgId },
        trainingExamples
      );
      
      // Save script to database for feedback tracking
      const savedScript = await storage.createSalesScript({
        roNumber: (req.body.roNumber as string) || null,
        customerName: request.customerName,
        scriptPayload: script,
        outcome: null,
        feedbackNotes: null,
      }, orgId);
      
      // Return script with ID for feedback
      res.json({ ...script, scriptId: savedScript.id });
    } catch (error) {
      console.error("Error generating script:", error);
      if (error instanceof Error) {
        res.status(500).json({ 
          error: "Failed to generate script",
          message: error.message 
        });
      } else {
        res.status(500).json({ error: "Failed to generate script" });
      }
    }
  });

  // Price Shopper / Incoming Caller Script Generation
  app.post("/api/scripts/price-shopper", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      
      console.log('[Price Shopper] Request body:', JSON.stringify(req.body, null, 2));
      
      // Validate request with Zod schema
      const validationResult = incomingCallerRequestSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        console.error('[Price Shopper] Validation failed:', validationResult.error.errors);
        return res.status(400).json({ 
          error: "Invalid request data",
          details: validationResult.error.errors.map(e => ({
            path: e.path.join('.'),
            message: e.message,
          })),
        });
      }
      
      const request = validationResult.data;
      
      // Import price shopper script generation function
      const { generatePriceShopperScript } = await import('./openai');
      
      // Generate price shopper conversion script
      const script = await generatePriceShopperScript(request);
      
      res.json(script);
    } catch (error) {
      console.error("Error generating price shopper script:", error);
      if (error instanceof Error) {
        res.status(500).json({ 
          error: "Failed to generate price shopper script",
          message: error.message 
        });
      } else {
        res.status(500).json({ error: "Failed to generate price shopper script" });
      }
    }
  });

  // Tekmetric Integration endpoints (for future real API integration)
  app.get("/api/tekmetric/customers/:id", async (req, res) => {
    try {
      if (!tekmetricClient) {
        return res.status(501).json({ 
          error: "Tekmetric integration not configured",
          message: "TEKMETRIC_API_KEY environment variable is required" 
        });
      }
      
      const customer = await tekmetricClient.getCustomer(req.params.id);
      if (!customer) {
        return res.status(404).json({ error: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      console.error("Error fetching Tekmetric customer:", error);
      res.status(500).json({ error: "Failed to fetch customer data" });
    }
  });

  app.get("/api/tekmetric/vehicles/:id", async (req, res) => {
    try {
      if (!tekmetricClient) {
        return res.status(501).json({ 
          error: "Tekmetric integration not configured" 
        });
      }
      
      const vehicle = await tekmetricClient.getVehicle(req.params.id);
      if (!vehicle) {
        return res.status(404).json({ error: "Vehicle not found" });
      }
      res.json(vehicle);
    } catch (error) {
      console.error("Error fetching Tekmetric vehicle:", error);
      res.status(500).json({ error: "Failed to fetch vehicle data" });
    }
  });

  app.get("/api/tekmetric/repair-orders/:id", async (req, res) => {
    try {
      if (!tekmetricClient) {
        return res.status(501).json({ 
          error: "Tekmetric integration not configured" 
        });
      }
      
      const ro = await tekmetricClient.getRepairOrder(parseInt(req.params.id));
      if (!ro) {
        return res.status(404).json({ error: "Repair order not found" });
      }
      
      // Fetch customer and vehicle details
      let customer = null;
      let vehicle = null;
      
      if (ro.customerId) {
        customer = await tekmetricClient.getCustomer(ro.customerId);
      }
      
      if (ro.vehicleId) {
        vehicle = await tekmetricClient.getVehicle(ro.vehicleId);
      }
      
      // Calculate totals from actual Tekmetric field names
      const roAny = ro as any;
      const laborSales = roAny.laborSales || 0;
      const partsSales = roAny.partsSales || 0;
      const subletSales = roAny.subletSales || 0;
      const feeTotal = roAny.feeTotal || 0;
      const discountTotal = roAny.discountTotal || 0;
      const taxes = roAny.taxes || 0;
      const totalSales = roAny.totalSales || 0;
      
      // Subtotal = Labor + Parts + Sublets + Fees - Discounts (before tax)
      const calculatedSubtotal = laborSales + partsSales + subletSales + feeTotal - discountTotal;
      
      console.log('[Tekmetric] Raw financial data from API:', {
        laborSales,
        partsSales,
        subletSales,
        feeTotal,
        discountTotal,
        taxes,
        totalSales,
        calculatedSubtotal
      });
      
      // Parse Tekmetric repair order into extension-friendly format
      const parsedData = {
        roNumber: ro.repairOrderNumber || req.params.id,
        customerId: ro.customerId,
        vehicleId: ro.vehicleId,
        customerName: customer ? `${customer.firstName || ''} ${customer.lastName || ''}`.trim() : null,
        vehicleInfo: vehicle ? {
          year: vehicle.year?.toString() || '',
          make: vehicle.make || '',
          model: vehicle.model || '',
          mileage: vehicle.mileage || null
        } : null,
        serviceWriter: null,
        technician: null,
        mileage: vehicle?.mileage || null,
        concerns: [],
        repairOrders: [] as Array<{
          service: string;
          priority: string;
          price: number;
          description: string;
        }>,
        // Convert from cents to dollars and round to 2 decimal places
        grandTotal: Math.round(totalSales) / 100,
        subtotal: Math.round(calculatedSubtotal) / 100,
        tax: Math.round(taxes) / 100,
      };
      
      // Parse jobs and extract pricing (Tekmetric returns prices in CENTS)
      if (ro.jobs && Array.isArray(ro.jobs)) {
        ro.jobs.forEach((job: any) => {
          const laborTotal = (job.laborTotal || 0) / 100; // Convert cents to dollars
          const partsTotal = (job.partsTotal || 0) / 100; // Convert cents to dollars
          // Round to 2 decimal places to avoid floating-point precision errors
          const jobTotal = Math.round((laborTotal + partsTotal) * 100) / 100;
          
          // Determine priority based on authorization status
          let priority = 'recommended';
          if (job.authorized === true) {
            priority = 'recommended'; // Approved by customer
          } else if (job.authorized === false) {
            priority = 'optional'; // Declined by customer
          }
          
          // Extract job name/description
          let serviceName = job.name || job.description || `Job #${job.id}`;
          
          // If job has labor items, try to get description from first labor item
          if (job.labor && job.labor.length > 0 && job.labor[0].description) {
            serviceName = job.labor[0].description;
          }
          
          parsedData.repairOrders.push({
            service: serviceName,
            priority: priority,
            price: jobTotal,
            description: job.description || job.notes || '',
          });
        });
      }
      
      console.log('[Tekmetric] Parsed repair order:', {
        roNumber: parsedData.roNumber,
        customer: parsedData.customerName,
        vehicle: vehicle ? `${vehicle.year} ${vehicle.make} ${vehicle.model}` : 'N/A',
        jobCount: parsedData.repairOrders.length,
        subtotal: parsedData.subtotal.toFixed(2),
        tax: parsedData.tax.toFixed(2),
        grandTotal: parsedData.grandTotal.toFixed(2),
      });
      
      res.json(parsedData);
    } catch (error) {
      console.error("Error fetching Tekmetric repair order:", error);
      res.status(500).json({ error: "Failed to fetch repair order data" });
    }
  });

  // Conversations - for feedback tracking and training data
  app.post("/api/conversations", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const data = insertConversationSchema.parse(req.body);
      
      const conversation = await storage.createConversation(data, orgId);
      
      res.json(conversation);
    } catch (error) {
      console.error("Error creating conversation:", error);
      if (error instanceof Error && error.name === "ZodError") {
        res.status(400).json({ error: "Invalid conversation data", details: error.message });
      } else {
        res.status(400).json({ error: "Invalid conversation data" });
      }
    }
  });

  app.get("/api/conversations", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const conversations = await storage.getConversations(orgId);
      res.json(conversations);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ error: "Failed to fetch conversations" });
    }
  });

  app.get("/api/conversations/:id", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const conversation = await storage.getConversation(req.params.id, orgId);
      
      if (!conversation) {
        res.status(404).json({ error: "Conversation not found" });
        return;
      }
      
      res.json(conversation);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ error: "Failed to fetch conversation" });
    }
  });

  // Record feedback (thumbs up/down with optional notes)
  const feedbackSchema = z.object({
    outcome: z.enum(["success", "failure"]),
    feedbackNotes: z.string().optional().nullable(),
  });

  app.patch("/api/conversations/:id/feedback", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const data = feedbackSchema.parse(req.body);
      
      const updated = await storage.updateConversationFeedback(
        req.params.id,
        data.outcome,
        data.feedbackNotes || null,
        orgId
      );
      
      if (!updated) {
        res.status(404).json({ error: "Conversation not found" });
        return;
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating conversation feedback:", error);
      if (error instanceof Error && error.name === "ZodError") {
        res.status(400).json({ error: "Invalid feedback data", details: error.message });
      } else {
        res.status(500).json({ error: "Failed to update feedback" });
      }
    }
  });

  // Sales Script Feedback
  app.patch("/api/sales-scripts/:id/feedback", async (req, res) => {
    try {
      const orgId = getCurrentOrg(req);
      const data = feedbackSchema.parse(req.body);
      
      const updated = await storage.updateSalesScriptFeedback(
        req.params.id,
        data.outcome,
        data.feedbackNotes || null,
        orgId
      );
      
      if (!updated) {
        res.status(404).json({ error: "Sales script not found" });
        return;
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating sales script feedback:", error);
      if (error instanceof Error && error.name === "ZodError") {
        res.status(400).json({ error: "Invalid feedback data", details: error.message });
      } else {
        res.status(500).json({ error: "Failed to update feedback" });
      }
    }
  });

  // Concern Intake: Generate follow-up questions
  app.post("/api/concerns/generate-questions", async (req, res) => {
    try {
      const data = generateConcernQuestionsRequestSchema.parse(req.body);
      const result = await generateConcernFollowUpQuestions(data);
      res.json(result);
    } catch (error) {
      console.error("Error generating concern questions:", error);
      if (error instanceof Error && error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.message });
      } else {
        res.status(500).json({ error: "Failed to generate questions" });
      }
    }
  });

  // Concern Intake: Review conversation and generate additional questions
  app.post("/api/concerns/review", async (req, res) => {
    try {
      const data = reviewConcernConversationRequestSchema.parse(req.body);
      const result = await reviewConcernConversation(data);
      res.json(result);
    } catch (error) {
      console.error("Error reviewing concern conversation:", error);
      if (error instanceof Error && error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.message });
      } else {
        res.status(500).json({ error: "Failed to review conversation" });
      }
    }
  });

  // Concern Intake: Clean conversation text
  app.post("/api/concerns/clean-conversation", async (req, res) => {
    try {
      const data = cleanConversationRequestSchema.parse(req.body);
      const result = await cleanConcernConversation(data);
      res.json(result);
    } catch (error) {
      console.error("Error cleaning conversation:", error);
      if (error instanceof Error && error.name === "ZodError") {
        res.status(400).json({ error: "Invalid request data", details: error.message });
      } else {
        res.status(500).json({ error: "Failed to clean conversation" });
      }
    }
  });

  // Chrome Extension Download
  app.get("/api/extension/download", async (req, res) => {
    try {
      const extensionPath = path.join(process.cwd(), 'extension');
      
      // Check if extension directory exists
      if (!fs.existsSync(extensionPath)) {
        return res.status(404).json({ error: "Extension files not found" });
      }
      
      // Set response headers for download
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="ai-sales-assistant-extension.zip"');
      
      // Create archive
      const archive = archiver('zip', {
        zlib: { level: 9 } // Maximum compression
      });
      
      // Pipe archive to response
      archive.pipe(res);
      
      // Add extension directory to archive
      archive.directory(extensionPath, false);
      
      // Finalize archive
      await archive.finalize();
      
      console.log('[Extension Download] Extension downloaded successfully');
    } catch (error) {
      console.error("Error creating extension archive:", error);
      res.status(500).json({ error: "Failed to create extension download" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
