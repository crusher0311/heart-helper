// Reference: javascript_database blueprint
import {
  organizations,
  trainingExamples,
  objectionResponses,
  conversations,
  salesScripts,
  type Organization,
  type InsertOrganization,
  type TrainingExample,
  type InsertTrainingExample,
  type ObjectionResponse,
  type InsertObjectionResponse,
  type Conversation,
  type InsertConversation,
  type SalesScript,
  type InsertSalesScript,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // Organizations
  getOrganization(id: string): Promise<Organization | undefined>;
  createOrganization(org: InsertOrganization): Promise<Organization>;
  updateOrganization(id: string, data: Partial<InsertOrganization>): Promise<Organization | undefined>;
  
  // Training Examples
  getTrainingExamples(organizationId: string): Promise<TrainingExample[]>;
  createTrainingExample(example: InsertTrainingExample, organizationId: string): Promise<TrainingExample>;
  deleteTrainingExample(id: string, organizationId: string): Promise<void>;
  
  // Objection Responses
  getObjectionResponses(organizationId: string): Promise<ObjectionResponse[]>;
  createObjectionResponse(response: InsertObjectionResponse, organizationId: string): Promise<ObjectionResponse>;
  deleteObjectionResponse(id: string, organizationId: string): Promise<void>;
  
  // Conversations
  createConversation(conversation: InsertConversation, organizationId: string): Promise<Conversation>;
  getConversation(id: string, organizationId: string): Promise<Conversation | undefined>;
  getConversations(organizationId: string): Promise<Conversation[]>;
  updateConversationFeedback(id: string, outcome: "success" | "failure", feedbackNotes: string | null, organizationId: string): Promise<Conversation | undefined>;
  
  // Sales Scripts
  createSalesScript(script: InsertSalesScript, organizationId: string): Promise<SalesScript>;
  getSalesScript(id: string, organizationId: string): Promise<SalesScript | undefined>;
  getSalesScripts(organizationId: string, roNumber?: string): Promise<SalesScript[]>;
  updateSalesScriptFeedback(id: string, outcome: "success" | "failure", feedbackNotes: string | null, organizationId: string): Promise<SalesScript | undefined>;
}

export class DatabaseStorage implements IStorage {
  // Organizations
  async getOrganization(id: string): Promise<Organization | undefined> {
    const [org] = await db.select().from(organizations).where(eq(organizations.id, id));
    return org || undefined;
  }

  async createOrganization(insertOrg: InsertOrganization): Promise<Organization> {
    // For default org, use fixed ID
    const values = insertOrg.name === "Default Organization" 
      ? { id: "default-org", ...insertOrg }
      : insertOrg;
    const [org] = await db.insert(organizations).values(values).returning();
    return org;
  }

  async updateOrganization(id: string, data: Partial<InsertOrganization>): Promise<Organization | undefined> {
    const [updated] = await db.update(organizations)
      .set(data)
      .where(eq(organizations.id, id))
      .returning();
    return updated || undefined;
  }

  // Training Examples
  async getTrainingExamples(organizationId: string): Promise<TrainingExample[]> {
    return db.select().from(trainingExamples).where(eq(trainingExamples.organizationId, organizationId));
  }

  async createTrainingExample(example: InsertTrainingExample, organizationId: string): Promise<TrainingExample> {
    const [created] = await db.insert(trainingExamples).values({
      ...example,
      organizationId,
    }).returning();
    return created;
  }

  async deleteTrainingExample(id: string, organizationId: string): Promise<void> {
    // Ensure user can only delete their own organization's data
    await db.delete(trainingExamples).where(
      and(
        eq(trainingExamples.id, id),
        eq(trainingExamples.organizationId, organizationId)
      )
    );
  }

  // Objection Responses
  async getObjectionResponses(organizationId: string): Promise<ObjectionResponse[]> {
    return db.select().from(objectionResponses).where(eq(objectionResponses.organizationId, organizationId));
  }

  async createObjectionResponse(response: InsertObjectionResponse, organizationId: string): Promise<ObjectionResponse> {
    const [created] = await db.insert(objectionResponses).values({
      ...response,
      organizationId,
    }).returning();
    return created;
  }

  async deleteObjectionResponse(id: string, organizationId: string): Promise<void> {
    // Ensure user can only delete their own organization's data
    await db.delete(objectionResponses).where(
      and(
        eq(objectionResponses.id, id),
        eq(objectionResponses.organizationId, organizationId)
      )
    );
  }

  // Conversations
  async createConversation(conversation: InsertConversation, organizationId: string): Promise<Conversation> {
    const [created] = await db.insert(conversations).values({
      ...conversation,
      organizationId,
    }).returning();
    return created;
  }

  async getConversation(id: string, organizationId: string): Promise<Conversation | undefined> {
    const [conversation] = await db.select().from(conversations).where(
      and(
        eq(conversations.id, id),
        eq(conversations.organizationId, organizationId)
      )
    );
    return conversation || undefined;
  }

  async getConversations(organizationId: string): Promise<Conversation[]> {
    return db.select().from(conversations)
      .where(eq(conversations.organizationId, organizationId))
      .orderBy(desc(conversations.createdAt));
  }

  async updateConversationFeedback(
    id: string,
    outcome: "success" | "failure",
    feedbackNotes: string | null,
    organizationId: string
  ): Promise<Conversation | undefined> {
    // First check if conversation exists
    const existing = await this.getConversation(id, organizationId);
    if (!existing) {
      return undefined;
    }
    
    // Update and return
    const [updated] = await db.update(conversations)
      .set({
        outcome,
        feedbackNotes,
      })
      .where(
        and(
          eq(conversations.id, id),
          eq(conversations.organizationId, organizationId)
        )
      )
      .returning();
    return updated;
  }

  // Sales Scripts
  async createSalesScript(script: InsertSalesScript, organizationId: string): Promise<SalesScript> {
    const [created] = await db.insert(salesScripts).values({
      ...script,
      organizationId,
    }).returning();
    return created;
  }

  async getSalesScript(id: string, organizationId: string): Promise<SalesScript | undefined> {
    const [script] = await db.select().from(salesScripts).where(
      and(
        eq(salesScripts.id, id),
        eq(salesScripts.organizationId, organizationId)
      )
    );
    return script || undefined;
  }

  async getSalesScripts(organizationId: string, roNumber?: string): Promise<SalesScript[]> {
    const conditions = [eq(salesScripts.organizationId, organizationId)];
    if (roNumber) {
      conditions.push(eq(salesScripts.roNumber, roNumber));
    }
    return db.select().from(salesScripts)
      .where(and(...conditions))
      .orderBy(desc(salesScripts.createdAt));
  }

  async updateSalesScriptFeedback(
    id: string,
    outcome: "success" | "failure",
    feedbackNotes: string | null,
    organizationId: string
  ): Promise<SalesScript | undefined> {
    const existing = await this.getSalesScript(id, organizationId);
    if (!existing) {
      return undefined;
    }
    
    const [updated] = await db.update(salesScripts)
      .set({
        outcome,
        feedbackNotes,
      })
      .where(
        and(
          eq(salesScripts.id, id),
          eq(salesScripts.organizationId, organizationId)
        )
      )
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
