// Tekmetric API client for fetching customer, vehicle, and repair order data
// Based on official Tekmetric API documentation: https://api.tekmetric.com/

export interface TekmetricCustomer {
  id: number;
  firstName: string;
  lastName: string;
  email?: string;
  phone?: Array<{
    number: string;
    type: string;
    primary: boolean;
  }>;
  customerType?: {
    id: number;
    code: string;
    name: string;
  };
  address?: {
    address1?: string;
    address2?: string;
    city?: string;
    state?: string;
    zip?: string;
    streetAddress?: string;
    fullAddress?: string;
  };
  shopId: number;
}

export interface TekmetricVehicle {
  id: number;
  customerId: number;
  year: number;
  make: string;
  model: string;
  submodel?: string;
  engine?: string;
  transmission?: string;
  vin?: string;
  color?: string;
  licensePlate?: string;
  mileage?: number;
  mileageUnit?: string;
  shopId: number;
}

export interface TekmetricRepairOrder {
  id: number;
  customerId: number;
  vehicleId: number;
  shopId: number;
  status: string;
  statusId: number;
  authorizedDate?: string;
  completedDate?: string;
  promisedDate?: string;
  subtotal: number;
  tax: number;
  total: number;
  jobs?: Array<{
    id: number;
    name: string;
    description?: string;
    technicianId?: number;
    laborAmount: number;
    partsAmount: number;
    total: number;
    status: string;
    authorization: string;
  }>;
  createdDate: string;
  updatedDate?: string;
}

export class TekmetricClient {
  private apiKey: string;
  private baseUrl: string;
  private shopId: string;

  constructor(apiKey: string, shopId: string, isProduction: boolean = true) {
    this.apiKey = apiKey;
    this.shopId = shopId;
    // Based on official Tekmetric API documentation
    // Production uses shop.tekmetric.com, NOT api.tekmetric.com
    this.baseUrl = "https://shop.tekmetric.com/api/v1";
  }

  private async makeRequest<T>(endpoint: string): Promise<T | null> {
    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        console.error(`[Tekmetric] API error: ${response.status} ${response.statusText}`);
        return null;
      }

      return await response.json();
    } catch (error) {
      console.error(`[Tekmetric] Request failed:`, error);
      return null;
    }
  }

  async getCustomer(customerId: number): Promise<TekmetricCustomer | null> {
    console.log(`[Tekmetric] Fetching customer ${customerId}`);
    return this.makeRequest<TekmetricCustomer>(`/customers/${customerId}`);
  }

  async getCustomers(search?: string): Promise<TekmetricCustomer[]> {
    console.log(`[Tekmetric] Fetching customers for shop ${this.shopId}`);
    const params = new URLSearchParams({ shop: this.shopId });
    if (search) params.append('search', search);
    
    const response = await this.makeRequest<{content: TekmetricCustomer[]}>(`/customers?${params}`);
    return response?.content || [];
  }

  async getVehicle(vehicleId: number): Promise<TekmetricVehicle | null> {
    console.log(`[Tekmetric] Fetching vehicle ${vehicleId}`);
    return this.makeRequest<TekmetricVehicle>(`/vehicles/${vehicleId}`);
  }

  async getCustomerVehicles(customerId: number): Promise<TekmetricVehicle[]> {
    console.log(`[Tekmetric] Fetching vehicles for customer ${customerId}`);
    const params = new URLSearchParams({ 
      shop: this.shopId,
      customerId: customerId.toString()
    });
    
    const response = await this.makeRequest<{content: TekmetricVehicle[]}>(`/vehicles?${params}`);
    return response?.content || [];
  }

  async getRepairOrder(roId: number): Promise<TekmetricRepairOrder | null> {
    console.log(`[Tekmetric] Fetching repair order ${roId} for shop ${this.shopId}`);
    const params = new URLSearchParams({ shop: this.shopId });
    return this.makeRequest<TekmetricRepairOrder>(`/repair-orders/${roId}?${params}`);
  }

  async getRepairOrders(customerId?: number, vehicleId?: number): Promise<TekmetricRepairOrder[]> {
    console.log(`[Tekmetric] Fetching repair orders for shop ${this.shopId}`);
    const params = new URLSearchParams({ shop: this.shopId });
    if (customerId) params.append('customerId', customerId.toString());
    if (vehicleId) params.append('vehicleId', vehicleId.toString());
    
    const response = await this.makeRequest<{content: TekmetricRepairOrder[]}>(`/repair-orders?${params}`);
    return response?.content || [];
  }
}

// Export singleton instance - requires both API key and shop ID
export const tekmetricClient = (process.env.TEKMETRIC_API_KEY && process.env.TEKMETRIC_SHOP_ID)
  ? new TekmetricClient(
      process.env.TEKMETRIC_API_KEY, 
      process.env.TEKMETRIC_SHOP_ID,
      process.env.NODE_ENV === 'production'
    )
  : null;
