// Reference: javascript_openai blueprint
import OpenAI from "openai";
import type { 
  GenerateScriptRequest, 
  GeneratedScript, 
  TrainingExample, 
  IncomingCallerRequest, 
  PriceShopperScript, 
  ObjectionType,
  GenerateConcernQuestionsRequest,
  GenerateConcernQuestionsResponse,
  ReviewConcernConversationRequest,
  ReviewConcernConversationResponse,
  CleanConversationRequest,
  CleanConversationResponse
} from "@shared/schema";

// Using GPT-4o, the latest available OpenAI model
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Deterministic objection detection
function detectObjection(answer: string | undefined): ObjectionType {
  if (!answer) return null;
  
  const lowerAnswer = answer.toLowerCase();
  
  // Price objections
  if (lowerAnswer.includes('price') || 
      lowerAnswer.includes('cost') || 
      lowerAnswer.includes('expensive') || 
      lowerAnswer.includes('cheaper') ||
      lowerAnswer.includes('budget') ||
      lowerAnswer.includes('afford') ||
      lowerAnswer.includes('money') ||
      lowerAnswer.includes('how much')) {
    return 'price';
  }
  
  // Timing objections
  if (lowerAnswer.includes('busy') || 
      lowerAnswer.includes('later') || 
      lowerAnswer.includes('think about') ||
      lowerAnswer.includes('call back') ||
      lowerAnswer.includes('not now') ||
      lowerAnswer.includes('another time')) {
    return 'timing';
  }
  
  // Trust objections
  if (lowerAnswer.includes('not sure') || 
      lowerAnswer.includes('don\'t know') || 
      lowerAnswer.includes('heard') ||
      lowerAnswer.includes('reviews') ||
      lowerAnswer.includes('trust') ||
      lowerAnswer.includes('guarantee') ||
      lowerAnswer.includes('warranty')) {
    return 'trust';
  }
  
  return null;
}

export async function generateSalesScript(
  request: GenerateScriptRequest,
  trainingExamples: TrainingExample[]
): Promise<GeneratedScript> {
  const { customerName, vehicleInfo, repairOrders, grandTotal, subtotal, tax } = request;

  // Build training context from approved examples
  const approvedExamples = trainingExamples.filter(e => e.category === "approved");
  const avoidExamples = trainingExamples.filter(e => e.category === "avoid");

  const approvedScripts = approvedExamples
    .map(e => e.content)
    .join("\n\n");

  const avoidPatterns = avoidExamples.map(e => e.content).join("\n");

  const systemPrompt = `You are an expert automotive service advisor sales assistant. Generate professional, customer-focused sales scripts.

${approvedScripts ? `APPROVED SCRIPT EXAMPLES (follow these patterns):\n${approvedScripts}\n` : ""}

${avoidPatterns ? `AVOID THESE PATTERNS:\n${avoidPatterns}\n` : ""}

CRITICAL GUIDELINES:
- Keep scripts SHORT and friendly - customers will ask for details if they want more
- ALWAYS mention the digital inspection early in the conversation
- ALWAYS use "total investment" instead of "grand total" or "total cost"
- ALWAYS mention our "3-year 36,000 mile nationwide warranty" when discussing the investment
- Build trust quickly with warmth, not lengthy explanations
- Be upbeat and conversational
- Let customers ask questions rather than over-explaining

Example digital inspection mention: "I sent over a copy of your digital inspection, did you get it? Great! Would you mind opening it up and we can go over it together?"
Example warranty mention: "Your total investment today is $550, and that's backed by our 3-year, 36,000 mile nationwide warranty."
Example alternative: "The investment for these services is $1,200, which includes our 3-year, 36,000 mile nationwide warranty on parts and labor."`;

  // Calculate total for display (use grandTotal if provided, otherwise sum repair orders)
  const totalAmount = grandTotal !== undefined 
    ? grandTotal 
    : repairOrders.reduce((sum, ro) => sum + ro.price, 0);
  
  const userPrompt = `Generate a SHORT, friendly, upbeat sales script for this customer:

Customer: ${customerName}
Vehicle: ${vehicleInfo.year} ${vehicleInfo.make} ${vehicleInfo.model} (${vehicleInfo.mileage} miles)

Repair Orders:
${repairOrders.map((ro, i) => `${i + 1}. ${ro.service} ($${ro.price.toFixed(2)}) - ${ro.priority.toUpperCase()}${ro.description ? ` - ${ro.description}` : ""}`).join("\n")}

${grandTotal !== undefined ? `\nPricing Summary:
- Subtotal: $${(subtotal || 0).toFixed(2)}
- Tax: $${(tax || 0).toFixed(2)}
- Total (including all taxes and fees): $${grandTotal.toFixed(2)}
` : ''}

Keep it BRIEF and friendly. Include:
- Warm greeting with their name
- MUST mention the digital inspection (e.g., "I sent over a copy of your digital inspection, did you get it? Great! Would you mind opening it up and we can go over it together?")
- Quick vehicle reference
- Concise mention of services (focus on critical items, briefly mention others)
- MUST say "total investment" (NOT "grand total") with exact amount: $${totalAmount.toFixed(2)}
- MUST mention "3-year, 36,000 mile nationwide warranty" when stating the investment
- Friendly close with next steps

CRITICAL RULES:
1. Must mention the digital inspection early in the script
2. Use "total investment" (never "grand total" or "total cost")
3. Must include the warranty mention when stating the investment
4. The total investment is exactly $${totalAmount.toFixed(2)} from Tekmetric (do NOT calculate yourself)
5. Keep it SHORT - let them ask for more details if they want
6. Stay upbeat and conversational

Return as JSON:
{
  "script": "the complete brief conversation",
  "repairPriorities": [
    {
      "service": "service name",
      "benefit": "brief benefit statement",
      "priority": "critical|recommended|optional",
      "price": number
    }
  ]
}`;

  try {
    console.log('[OpenAI] Calling OpenAI API with model: gpt-4o');
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // Using GPT-4o, the latest available model
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 2048,
    });

    const content = response.choices[0]?.message?.content || "{}";
    console.log("[OpenAI] Raw response:", content);
    console.log("[OpenAI] Response object:", JSON.stringify(response, null, 2));
    
    const result = JSON.parse(content);
    
    // Handle both old format (opening/closing) and new format (script)
    if (result.script) {
      // New format - single fluid script
      result.opening = result.script;
      result.closing = "";
    } else if (result.opening || result.closing) {
      // Old format - combine into single script
      const parts = [result.opening, result.closing].filter(Boolean);
      result.script = parts.join("\n\n");
    }
    
    // Validate response has required fields
    if (!result.script && !result.opening) {
      console.error("[OpenAI] Invalid response format:", result);
      throw new Error("OpenAI response missing required fields");
    }
    
    // Ensure repairPriorities is an array
    if (!Array.isArray(result.repairPriorities)) {
      console.error("[OpenAI] repairPriorities is not an array:", result.repairPriorities);
      result.repairPriorities = [];
    }
    
    // Validate each repair priority has required fields
    result.repairPriorities = result.repairPriorities.map((rp: any) => ({
      service: rp.service || "Unknown Service",
      benefit: rp.benefit || "This service is recommended for your vehicle.",
      priority: rp.priority || "recommended",
      price: typeof rp.price === "number" ? rp.price : 0,
    }));
    
    console.log("[OpenAI] Validated response:", JSON.stringify(result, null, 2));
    return result as GeneratedScript;
  } catch (error) {
    console.error("OpenAI API error:", error);
    if (error instanceof Error) {
      throw new Error(`Failed to generate script: ${error.message}`);
    }
    throw new Error("Failed to generate script");
  }
}

export async function generatePriceShopperScript(
  request: IncomingCallerRequest
): Promise<PriceShopperScript> {
  const { customerName, referralSource, symptoms, vehicleInfo, conversationHistory = [] } = request;

  // Detect objection in last answer before calling OpenAI
  const hasConversation = conversationHistory.length > 0;
  const lastAnswer = hasConversation ? conversationHistory[conversationHistory.length - 1]?.answer : null;
  const objectionDetected = detectObjection(lastAnswer);

  const systemPrompt = `You are an expert automotive service advisor sales coach. Guide advisors through ONE question at a time in phone conversations with price shoppers.

CRITICAL PHILOSOPHY:
- Build rapport through diagnostic questions, not price quotes
- Each question should reveal complexity and build trust
- Handle objections with empathy and value positioning
- Questions must be SPECIFIC to their symptoms (e.g., brake questions for brake issues)
- After 3-4 meaningful exchanges, transition to appointment booking

OBJECTION HANDLING SCRIPTS (use these verbatim when objection is detected):
- Price: "I understand budget is important. That's exactly why we offer a FREE inspection - so you know exactly what you need before spending anything. How's tomorrow at 2pm?"
- Timing: "I totally get it. How about we get you on the schedule for when it works for you? Even if it's a week or two out, at least you're locked in."
- Trust: "I appreciate your caution. We've been serving this community for years. How about this - come in for a free inspection, no obligation. You can decide after you see what's needed."

QUESTION STRATEGY (when NO objection):
- Question 1: Specific symptom detail (e.g., "When you press the brakes, do you hear squealing or grinding?")
- Question 2: Related symptoms (e.g., "Have you noticed any vibration in the steering wheel when braking?")
- Question 3: Safety/urgency (e.g., "How long has this been happening? Is it getting worse?")
- Then: Appointment close

TONE: Friendly, expert, problem-solving focused`;

  const userPrompt = hasConversation
    ? `Continue this phone conversation. Generate the NEXT single question or close the appointment.

Customer: ${customerName || "Not provided"}
Symptoms: ${symptoms.join(", ") || "General inquiry"}
Vehicle: ${vehicleInfo ? `${vehicleInfo.year || ''} ${vehicleInfo.make || ''} ${vehicleInfo.model || ''}`.trim() : "Not provided"}

Conversation so far:
${conversationHistory.map((h, i) => {
  const objLabel = h.objectionDetected ? ` [${h.objectionDetected.toUpperCase()} OBJECTION]` : '';
  const respLabel = h.isObjectionResponse ? ' [HANDLED]' : '';
  return `${i + 1}. Q: ${h.question}${respLabel}\n   A: ${h.answer || "Skipped"}${objLabel}`;
}).join('\n')}

${objectionDetected ? `\n🚨 OBJECTION DETECTED IN LAST ANSWER: ${objectionDetected.toUpperCase()}\nYou MUST use the ${objectionDetected} objection handling script from above.` : ''}

Based on their symptoms and answers:
- If objection just detected: Use the corresponding objection handling script verbatim, then suggest appointment
- If 3+ questions asked without objection: Transition to appointment booking  
- Otherwise: Ask next diagnostic question SPECIFIC to their ${symptoms[0] || "issue"}

Return as JSON:
{
  "greeting": "${customerName && conversationHistory.length === 0 ? `Hi ${customerName}!` : ''} [only on first question]",
  "currentQuestion": "the next question or objection response",
  "shouldClose": ${(conversationHistory.length >= 3 && !objectionDetected) || false},
  "appointmentClose": "[only if shouldClose=true] transition to scheduling"
}`
    : `Start a new price shopper conversation. Generate the greeting and FIRST question.

Customer: ${customerName || "Not yet collected"}
Symptoms: ${symptoms.join(", ") || "Asking for price"}
Vehicle: ${vehicleInfo ? `${vehicleInfo.year || ''} ${vehicleInfo.make || ''} ${vehicleInfo.model || ''}`.trim() : "Not provided"}

${symptoms.length > 0 ? `Focus first question specifically on: "${symptoms[0]}"` : "Start by understanding what they're calling about"}

Return as JSON:
{
  "greeting": "Hi [Name]! Thanks for calling.",
  "currentQuestion": "What brings you in today? What's going on with your vehicle?",
  "shouldClose": false
}`;

  try {
    console.log('[OpenAI] Generating price shopper script');
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 800,
    });

    const content = response.choices[0]?.message?.content || "{}";
    console.log("[OpenAI] Price shopper script response:", content);
    
    const result = JSON.parse(content);
    
    // Validate response structure
    if (!result.currentQuestion) {
      console.error("[OpenAI] Invalid price shopper response format:", result);
      throw new Error("OpenAI response missing currentQuestion");
    }
    
    return {
      greeting: result.greeting || "",
      currentQuestion: result.currentQuestion,
      appointmentClose: result.appointmentClose,
      shouldClose: result.shouldClose || false,
      objectionDetected
    };
  } catch (error) {
    console.error("OpenAI API error (price shopper):", error);
    if (error instanceof Error) {
      throw new Error(`Failed to generate price shopper script: ${error.message}`);
    }
    throw new Error("Failed to generate price shopper script");
  }
}

// Concern Intake: Generate follow-up questions based on customer concern
export async function generateConcernFollowUpQuestions(
  request: GenerateConcernQuestionsRequest
): Promise<GenerateConcernQuestionsResponse> {
  const { customerConcern } = request;
  const limit = 5; // Limit to 5 questions as per original tool

  const systemPrompt = `You are assisting a service advisor who is speaking directly with a customer about their vehicle's issue. 
Your role is to generate thoughtful, diagnostic follow-up questions that help gather detailed information for the technician.

GUIDELINES:
- Generate exactly ${limit} follow-up questions
- Questions should be specific and diagnostic
- Focus on gathering details that help technicians diagnose the problem
- Keep questions clear and conversational
- Each question should end with a question mark`;

  const userPrompt = `The customer's concern is: "${customerConcern}"

Based on this concern, generate exactly ${limit} follow-up questions that the service advisor should ask the customer to gather detailed information for the technician to diagnose the problem more accurately.

Return as JSON array of question strings:
{
  "questions": ["Question 1?", "Question 2?", ...]
}`;

  try {
    console.log('[OpenAI] Generating concern follow-up questions');
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 1000,
    });

    const content = response.choices[0]?.message?.content || "{}";
    console.log("[OpenAI] Concern questions response:", content);
    
    const result = JSON.parse(content);
    
    if (!Array.isArray(result.questions)) {
      console.error("[OpenAI] Invalid concern questions format:", result);
      throw new Error("OpenAI response missing questions array");
    }

    // Ensure we have exactly the limit number of questions
    const questions = result.questions.slice(0, limit);
    
    return { questions };
  } catch (error) {
    console.error("OpenAI API error (concern questions):", error);
    if (error instanceof Error) {
      throw new Error(`Failed to generate concern questions: ${error.message}`);
    }
    throw new Error("Failed to generate concern questions");
  }
}

// Concern Intake: Review conversation and generate additional questions
export async function reviewConcernConversation(
  request: ReviewConcernConversationRequest
): Promise<ReviewConcernConversationResponse> {
  const { customerConcern, answeredQuestions, activeResponses = [] } = request;
  const limit = 5;

  const systemPrompt = `You are assisting a service advisor who is speaking directly with a customer to gather more details about their vehicle issue.

GUIDELINES:
- Generate up to ${limit} NEW follow-up questions
- Avoid questions that have already been answered
- Build on previous answers to dive deeper
- Focus on diagnostic details that weren't covered yet
- Each question should end with a question mark`;

  // Format conversation history
  const formattedAnswered = answeredQuestions
    .map(r => `Q: ${r.question}\nA: ${r.answer || "No answer"}`)
    .join('\n\n');
  
  const formattedActive = activeResponses
    .map(r => `Q: ${r.question}\nA: ${r.answer || "No answer"}`)
    .join('\n\n');

  const userPrompt = `Here is the entire conversation so far:

Customer Concern: ${customerConcern}

Follow-Up Questions and Responses:
${formattedAnswered}

${formattedActive ? `\nPrevious Follow-Up:\n${formattedActive}` : ''}

Based on the above conversation, what additional follow-up questions or information (limit: ${limit}) should the service advisor ask the customer to further clarify the issue? 
Please avoid questions that have already been answered and limit the number of new questions to ${limit}.

Return as JSON array of question strings:
{
  "additionalQuestions": ["Question 1?", "Question 2?", ...]
}`;

  try {
    console.log('[OpenAI] Reviewing concern conversation for additional questions');
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 1000,
    });

    const content = response.choices[0]?.message?.content || "{}";
    console.log("[OpenAI] Concern review response:", content);
    
    const result = JSON.parse(content);
    
    if (!Array.isArray(result.additionalQuestions)) {
      console.error("[OpenAI] Invalid concern review format:", result);
      throw new Error("OpenAI response missing additionalQuestions array");
    }

    const additionalQuestions = result.additionalQuestions.slice(0, limit);
    
    return { additionalQuestions };
  } catch (error) {
    console.error("OpenAI API error (concern review):", error);
    if (error instanceof Error) {
      throw new Error(`Failed to review concern conversation: ${error.message}`);
    }
    throw new Error("Failed to review concern conversation");
  }
}

// Concern Intake: Clean conversation into natural paragraph format
export async function cleanConcernConversation(
  request: CleanConversationRequest
): Promise<CleanConversationResponse> {
  const { conversationText } = request;

  const systemPrompt = `You are assisting in reviewing a conversation between a service advisor and a customer. 
Your role is to clean up and restructure the conversation into a clear, natural paragraph format.

GUIDELINES:
- Convert the conversation into smooth, flowing paragraph-style text
- Remove labels like "Service Advisor:" or "Customer:"
- Maintain all important information and context
- Make it sound natural and professional
- Keep it concise but complete`;

  const userPrompt = `The conversation so far is as follows:

${conversationText}

Please clean up this conversation into a clear, concise, and natural paragraph-style format. Ensure that the flow is smooth without extra labels like "Service Advisor" or "Customer."

Return as JSON:
{
  "cleanedConversation": "the cleaned paragraph text"
}`;

  try {
    console.log('[OpenAI] Cleaning concern conversation');
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 2000,
    });

    const content = response.choices[0]?.message?.content || "{}";
    console.log("[OpenAI] Cleaned conversation response:", content);
    
    const result = JSON.parse(content);
    
    if (!result.cleanedConversation) {
      console.error("[OpenAI] Invalid cleaned conversation format:", result);
      throw new Error("OpenAI response missing cleanedConversation");
    }
    
    return { cleanedConversation: result.cleanedConversation };
  } catch (error) {
    console.error("OpenAI API error (clean conversation):", error);
    if (error instanceof Error) {
      throw new Error(`Failed to clean concern conversation: ${error.message}`);
    }
    throw new Error("Failed to clean concern conversation");
  }
}
