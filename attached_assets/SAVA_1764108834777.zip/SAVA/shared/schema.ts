import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb, pgEnum, index } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const conversationTypeEnum = pgEnum("conversation_type", ["incoming_caller", "sales_script"]);
export const conversationOutcomeEnum = pgEnum("conversation_outcome", ["success", "failure"]);

// Organizations table for multi-tenant support
export const organizations = pgTable("organizations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  phoneAnswerScript: text("phone_answer_script"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Training examples for AI learning
export const trainingExamples = pgTable("training_examples", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  category: text("category").notNull(), // 'approved' or 'avoid'
  scriptType: text("script_type").notNull(), // 'opening', 'repair_priority', 'closing'
  content: text("content").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Objection responses library
export const objectionResponses = pgTable("objection_responses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  objectionType: text("objection_type").notNull(), // 'price', 'timing', 'trust'
  response: text("response").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Conversations with feedback tracking
export const conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  conversationType: conversationTypeEnum("conversation_type").notNull(),
  customerName: text("customer_name"),
  referralSource: text("referral_source"),
  symptoms: text("symptoms").array(),
  vehicleInfo: jsonb("vehicle_info"), // {year, make, model, mileage}
  conversationHistory: jsonb("conversation_history").notNull(), // Array of ConversationHistory
  outcome: conversationOutcomeEnum("outcome"), // 'success' | 'failure' | null (null = no feedback yet)
  feedbackNotes: text("feedback_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgCreatedIdx: index("conversations_org_created_idx").on(table.organizationId, table.createdAt),
  orgOutcomeIdx: index("conversations_org_outcome_idx").on(table.organizationId, table.outcome),
}));

// Sales scripts with feedback tracking
export const salesScripts = pgTable("sales_scripts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  roNumber: text("ro_number"),
  customerName: text("customer_name"),
  scriptPayload: jsonb("script_payload").notNull(), // Full GeneratedScript from OpenAI
  outcome: conversationOutcomeEnum("outcome"), // 'success' | 'failure' | null
  feedbackNotes: text("feedback_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgCreatedIdx: index("sales_scripts_org_created_idx").on(table.organizationId, table.createdAt),
  orgRoIdx: index("sales_scripts_org_ro_idx").on(table.organizationId, table.roNumber),
  orgOutcomeIdx: index("sales_scripts_org_outcome_idx").on(table.organizationId, table.outcome),
}));

// Relations
export const organizationsRelations = relations(organizations, ({ many }) => ({
  trainingExamples: many(trainingExamples),
  objectionResponses: many(objectionResponses),
  conversations: many(conversations),
  salesScripts: many(salesScripts),
}));

export const trainingExamplesRelations = relations(trainingExamples, ({ one }) => ({
  organization: one(organizations, {
    fields: [trainingExamples.organizationId],
    references: [organizations.id],
  }),
}));

export const objectionResponsesRelations = relations(objectionResponses, ({ one }) => ({
  organization: one(organizations, {
    fields: [objectionResponses.organizationId],
    references: [organizations.id],
  }),
}));

export const conversationsRelations = relations(conversations, ({ one }) => ({
  organization: one(organizations, {
    fields: [conversations.organizationId],
    references: [organizations.id],
  }),
}));

export const salesScriptsRelations = relations(salesScripts, ({ one }) => ({
  organization: one(organizations, {
    fields: [salesScripts.organizationId],
    references: [organizations.id],
  }),
}));

// Insert schemas
export const insertOrganizationSchema = createInsertSchema(organizations).omit({
  id: true,
  createdAt: true,
});

// Omit organizationId from insert schemas - server will inject from auth
export const insertTrainingExampleSchema = createInsertSchema(trainingExamples).omit({
  id: true,
  createdAt: true,
  organizationId: true,
});

export const insertObjectionResponseSchema = createInsertSchema(objectionResponses).omit({
  id: true,
  createdAt: true,
  organizationId: true,
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
  organizationId: true,
});

export const insertSalesScriptSchema = createInsertSchema(salesScripts).omit({
  id: true,
  createdAt: true,
  organizationId: true,
});

// Types
export type Organization = typeof organizations.$inferSelect;
export type InsertOrganization = z.infer<typeof insertOrganizationSchema>;

export type TrainingExample = typeof trainingExamples.$inferSelect;
export type InsertTrainingExample = z.infer<typeof insertTrainingExampleSchema>;

export type ObjectionResponse = typeof objectionResponses.$inferSelect;
export type InsertObjectionResponse = z.infer<typeof insertObjectionResponseSchema>;

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;

export type SalesScript = typeof salesScripts.$inferSelect;
export type InsertSalesScript = z.infer<typeof insertSalesScriptSchema>;

// API request/response types with Zod validation
export const vehicleInfoSchema = z.object({
  year: z.string().min(4, "Year must be at least 4 characters"),
  make: z.string().min(1, "Make is required"),
  model: z.string().min(1, "Model is required"),
  mileage: z.string().optional().default("Unknown"),
});

export const repairOrderSchema = z.object({
  service: z.string().min(1, "Service name is required"),
  priority: z.enum(['critical', 'recommended', 'optional']),
  price: z.number().min(0, "Price must be non-negative"),
  description: z.string().optional(),
});

export const generateScriptRequestSchema = z.object({
  organizationId: z.string().optional(),
  customerName: z.string().min(1, "Customer name is required"),
  vehicleInfo: vehicleInfoSchema,
  repairOrders: z.array(repairOrderSchema).min(1, "At least one repair order is required"),
  // Grand total from Tekmetric (includes taxes, fees, discounts)
  grandTotal: z.number().optional(),
  subtotal: z.number().optional(),
  tax: z.number().optional(),
});

export type GenerateScriptRequest = z.infer<typeof generateScriptRequestSchema>;

export type GeneratedScript = {
  script?: string;
  opening?: string;
  closing?: string;
  repairPriorities: Array<{
    service: string;
    benefit: string;
    priority: 'critical' | 'recommended' | 'optional';
    price: number;
  }>;
};

// API response wrapper that includes scriptId for feedback tracking
export type GenerateScriptResponse = GeneratedScript & { scriptId: string };

// Incoming caller / price shopper types
export type ObjectionType = "price" | "timing" | "trust" | null;

export const conversationHistorySchema = z.object({
  question: z.string(),
  answer: z.string().optional(),
  objectionDetected: z.enum(["price", "timing", "trust"]).nullable().optional(),
  isObjectionResponse: z.boolean().optional(),
});

export const incomingCallerRequestSchema = z.object({
  organizationId: z.string().optional(),
  customerName: z.string().optional(),
  referralSource: z.string().optional(),
  symptoms: z.array(z.string()).default([]),
  vehicleInfo: z.object({
    year: z.string().optional(),
    make: z.string().optional(),
    model: z.string().optional(),
  }).optional(),
  conversationHistory: z.array(conversationHistorySchema).default([]),
});

export type ConversationHistory = z.infer<typeof conversationHistorySchema>;
export type IncomingCallerRequest = z.infer<typeof incomingCallerRequestSchema>;

export type PriceShopperScript = {
  greeting: string;
  currentQuestion: string;
  appointmentClose?: string;
  shouldClose: boolean;
  objectionDetected?: ObjectionType;
};

// Concern Intake types (customer concern tool integration)
export const concernQuestionResponseSchema = z.object({
  question: z.string(),
  answer: z.string().optional(),
});

export type ConcernQuestionResponse = z.infer<typeof concernQuestionResponseSchema>;

export const generateConcernQuestionsRequestSchema = z.object({
  customerConcern: z.string().min(1, "Customer concern is required"),
});

export type GenerateConcernQuestionsRequest = z.infer<typeof generateConcernQuestionsRequestSchema>;

export type GenerateConcernQuestionsResponse = {
  questions: string[];
};

export const reviewConcernConversationRequestSchema = z.object({
  customerConcern: z.string().min(1, "Customer concern is required"),
  answeredQuestions: z.array(concernQuestionResponseSchema),
  activeResponses: z.array(concernQuestionResponseSchema).optional().default([]),
});

export type ReviewConcernConversationRequest = z.infer<typeof reviewConcernConversationRequestSchema>;

export type ReviewConcernConversationResponse = {
  additionalQuestions: string[];
};

export const cleanConversationRequestSchema = z.object({
  conversationText: z.string().min(1, "Conversation text is required"),
});

export type CleanConversationRequest = z.infer<typeof cleanConversationRequestSchema>;

export type CleanConversationResponse = {
  cleanedConversation: string;
};
