# Design Guidelines: AI Sales Assistant Chrome Extension for Tekmetric

## Design Approach
**System-Based Approach**: Material Design principles with automotive industry professionalism
- Clean, efficient interface optimized for rapid information consumption
- Trust-building aesthetics appropriate for financial/sales conversations
- Minimal distractions to keep advisors focused on customer interactions

## Typography System
**Font Stack**: Inter (Google Fonts) for clarity and professionalism
- **Script Headers**: 20px, semibold (600) - stands out for quick scanning
- **Body Text/Scripts**: 15px, regular (400) - optimized for reading aloud
- **Labels/Metadata**: 13px, medium (500) - customer/vehicle info
- **Objection Tags**: 12px, semibold (600), uppercase - quick visual identification

## Layout & Spacing
**Tailwind Units**: Consistently use 2, 4, 6, and 8 for all spacing
- **Side Panel Width**: 400px fixed (Chrome extension constraint)
- **Section Padding**: p-6 for main containers
- **Card Spacing**: gap-4 between cards, p-4 internal padding
- **Button Spacing**: px-6, py-3 for primary actions

## Extension Side Panel Structure

### 1. Header Bar (Fixed Top)
- Shop logo/name with current RO number
- Quick refresh button
- Compact height (h-16) with px-6 padding

### 2. Customer Context Card
- Customer name (18px, semibold)
- Vehicle info (14px): Year/Make/Model, Mileage
- Current RO status badge
- Compact layout using grid-cols-2 for key-value pairs

### 3. Script Generator Section
**Three Expandable Accordion Panels**:

**Opening Script Panel**
- Auto-generated greeting with customer name
- Key talking points (3-4 bullets)
- Copy-to-clipboard button (top-right corner)

**Repair Priorities Panel**
- Numbered list of recommended repairs (1-5 items)
- Each item: Service name + AI-generated benefit statement
- Priority indicators (Critical/Recommended/Optional)

**Closing Script Panel**
- Summary statement
- Next steps callout
- Confidence-building closer

### 4. Objection Handler (Bottom Sheet)
**Quick-Access Tabs**:
- Price Concerns | Timing Issues | Trust Building
- Each tab shows 2-3 pre-generated responses
- Toggle button to show/hide section

## Admin Dashboard Layout

### Navigation
**Sidebar (w-64)**:
- Dashboard
- Script Training
- Objection Library
- Shop Settings
- Analytics
- Stacked vertical navigation with icons

### Main Content Area (max-w-6xl, mx-auto)

**Training Interface**:
- Two-column layout (grid-cols-2)
- Left: "Approved Approaches" examples
- Right: "Avoid These" examples
- Add/Edit forms with simple textarea inputs

**Script Examples Library**:
- Searchable grid (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)
- Cards showing script type, context, and preview
- Edit/Delete actions on hover

## Component Library

### Cards
- Rounded corners (rounded-lg)
- Subtle elevation (shadow-sm)
- Clear content hierarchy with pb-4 spacing between sections

### Buttons
**Primary Action**: Full-width for script copying, px-6 py-3
**Secondary Actions**: Outline style for edit/customize
**Icon Buttons**: 40x40 square for quick actions

### Badges & Tags
- Rounded-full for status indicators
- px-3 py-1 for compact sizing
- Clear semantic meaning (Critical/Warning/Success states)

### Forms (Admin Dashboard)
- Labels above inputs (mb-2 spacing)
- Full-width text inputs with h-10 height
- Textareas with min-h-32 for script examples
- Helper text below inputs (text-sm, pt-1)

## Data Display Patterns

### Script Content
- Line-height: 1.6 for easy reading
- Max-width: prose for optimal reading length
- Clear paragraph breaks (mb-4)

### Customer/Vehicle Data
- Label-value pairs in grid layout
- Labels aligned right on desktop (text-right)
- Values semibold for emphasis

## Images
**No hero images required** - This is a utility extension focused on rapid information delivery. Visual branding limited to:
- Shop logo in header (max h-10)
- Empty state illustrations for "No active RO" scenarios
- Success confirmation icons for copied scripts

## Interaction Patterns
- Click to copy scripts (with success toast notification)
- Expand/collapse accordion sections (one open at a time)
- Smooth transitions (transition-all duration-200)
- Hover states show copy icons and edit options
- No auto-refresh - manual refresh button for intentional updates

## Critical UX Considerations
- All scripts must be scannable in under 3 seconds
- Copy buttons positioned consistently (top-right of each script section)
- Objection handler must be accessible within one click
- Admin training interface uses simple, familiar patterns (no complex workflows)
- Extension remains non-intrusive to Tekmetric interface (side panel only)