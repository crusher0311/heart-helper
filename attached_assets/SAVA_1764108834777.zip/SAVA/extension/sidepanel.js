// Side panel script - loads the main web app in an iframe

console.log('[Side Panel] Initializing...');

// Get API configuration from extension storage
chrome.runtime.sendMessage({ type: 'GET_API_CONFIG' }, (config) => {
  // Use Replit production URL by default
  const apiUrl = config?.apiUrl || 'https://105eb3e1-eaaa-4964-b7c6-9602d4c217ed-00-1t1pqb7mrp2pz.janeway.replit.dev';
  
  // Create iframe pointing to the extension page of the web app
  const iframe = document.createElement('iframe');
  iframe.src = `${apiUrl}/extension`;
  iframe.allow = 'clipboard-write';
  
  // Replace loading indicator with iframe
  const app = document.getElementById('app');
  app.innerHTML = '';
  app.appendChild(iframe);
  
  console.log('[Side Panel] Loaded web app from:', iframe.src);
  
  // Listen for Tekmetric data updates from background script
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'UPDATE_CUSTOMER_DATA' || message.type === 'FORWARD_TEKMETRIC_DATA') {
      console.log('[Side Panel] 📥 Received Tekmetric data from background:', {
        roNumber: message.data?.roNumber,
        customerName: message.data?.customerName,
        repairOrdersCount: message.data?.repairOrders?.length || 0
      });
      
      // Forward to iframe
      iframe.contentWindow.postMessage({
        type: 'TEKMETRIC_DATA',
        data: message.data
      }, apiUrl);
      
      console.log('[Side Panel] ✅ Forwarded data to iframe');
    }
  });
  
  // Listen for messages from iframe
  window.addEventListener('message', (event) => {
    // Accept messages from the iframe (web app origin)
    // The iframe is loaded from apiUrl, so check against that origin
    const iframeOrigin = new URL(apiUrl).origin;
    
    // Also accept messages from the content script forwarded by background
    const isChromeExtension = event.origin.startsWith('chrome-extension://');
    const isIframe = event.origin === iframeOrigin;
    
    if (!isIframe && !isChromeExtension) {
      console.log('[Side Panel] Ignoring message from unknown origin:', event.origin);
      return;
    }
    
    console.log('[Side Panel] Message from:', event.origin, 'Data:', event.data);
    
    // Handle any communication from the web app
    if (event.data.type === 'REQUEST_TEKMETRIC_DATA') {
      console.log('[Side Panel] Iframe requesting Tekmetric data');
      // Request fresh data from content script
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_TEKMETRIC_DATA' }, (response) => {
            // Check for runtime errors first
            if (chrome.runtime.lastError) {
              console.error('[Side Panel] ❌ Chrome runtime error:', chrome.runtime.lastError.message);
              console.error('[Side Panel] ⚠️ Content script may not be loaded on this page');
              // Send empty data so the iframe doesn't hang
              iframe.contentWindow.postMessage({
                type: 'TEKMETRIC_DATA',
                data: { repairOrders: [], concerns: [] }
              }, iframeOrigin);
              return;
            }
            
            console.log('[Side Panel] Received data from content script');
            console.log('[Side Panel] Response concerns count:', response?.concerns?.length || 0);
            console.log('[Side Panel] Response repairOrders count:', response?.repairOrders?.length || 0);
            console.log('[Side Panel] Full response:', response);
            
            // Handle undefined response (content script not loaded or errored)
            if (!response) {
              console.warn('[Side Panel] ⚠️ Content script returned undefined - it may not be loaded or errored');
              iframe.contentWindow.postMessage({
                type: 'TEKMETRIC_DATA',
                data: { repairOrders: [], concerns: [] }
              }, iframeOrigin);
              return;
            }
            
            // Send the data directly (no need for JSON clone)
            iframe.contentWindow.postMessage({
              type: 'TEKMETRIC_DATA',
              data: response
            }, iframeOrigin);
          });
        }
      });
    }
  });
});
