# AI Sales Assistant Chrome Extension

This Chrome extension integrates with Tekmetric to provide AI-powered sales scripts for automotive service advisors.

## Installation

### 1. Load Extension in Chrome

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top right)
3. Click "Load unpacked"
4. Select the `extension` folder from this project

### 2. Configure API Settings

The extension needs to connect to your AI Sales Assistant backend:

1. Click the extension icon in your browser toolbar
2. The side panel will open with settings
3. Configure:
   - **API URL**: Your backend URL (e.g., `http://localhost:5000` for development or `https://your-domain.replit.app` for production)
   - **Organization ID**: Your organization identifier (default: `default-org`)

### 3. Set Up Tekmetric Integration

The backend needs your Tekmetric API credentials:

1. Log in to your Tekmetric account
2. Navigate to Settings > Integrations > API
3. Generate an API key
4. Add to your backend environment:
   ```bash
   TEKMETRIC_API_KEY=your_api_key_here
   TEKMETRIC_SHOP_ID=your_shop_number
   ```

## Usage

### In Tekmetric

1. Navigate to a repair order in Tekmetric (`shop.tekmetric.com/repair-orders/...`)
2. Click the extension icon to open the AI Sales Assistant side panel
3. The extension will automatically detect the customer and vehicle information
4. Click "Generate Sales Script" to create personalized scripts
5. Use the Objection Handler for quick responses to common concerns
6. Copy scripts directly to your clipboard for use in conversations

### Features

- **Auto-Detection**: Automatically extracts customer and RO data from Tekmetric pages
- **Real-Time Generation**: Creates personalized scripts based on current repair order
- **Objection Handling**: Quick access to responses for price, timing, and trust concerns
- **Copy to Clipboard**: One-click copying of all scripts
- **Training Integration**: Uses your shop's custom training data

## Development

### File Structure

```
extension/
├── manifest.json        # Extension configuration
├── background.js        # Service worker (manages side panel and messaging)
├── content.js           # Injected into Tekmetric pages (extracts data)
├── sidepanel.html       # Side panel UI wrapper
├── sidepanel.js         # Loads main web app in iframe
├── icon16.png          # Extension icon (16x16)
├── icon48.png          # Extension icon (48x48)
├── icon128.png         # Extension icon (128x128)
└── README.md           # This file
```

### How It Works

1. **Content Script** (`content.js`):
   - Injected into all `shop.tekmetric.com` pages
   - Extracts repair order, customer, and vehicle data from the DOM
   - Monitors for page navigation in Tekmetric's SPA
   - Sends data to background script

2. **Background Service Worker** (`background.js`):
   - Manages side panel opening/closing
   - Handles message passing between content script and side panel
   - Stores API configuration in Chrome sync storage

3. **Side Panel** (`sidepanel.html` + `sidepanel.js`):
   - Loads the main web app in an iframe
   - Forwards Tekmetric data to the web app
   - Enables clipboard access for copy functionality

### Testing

1. Navigate to `shop.tekmetric.com` (or sandbox)
2. Open Developer Tools
3. Check Console for `[AI Sales Assistant]` messages
4. Verify data extraction in the side panel

### Permissions

The extension requires these permissions:

- `sidePanel`: Display the AI assistant in Chrome's side panel
- `storage`: Store API configuration
- `activeTab`: Access the current Tekmetric tab
- `scripting`: Inject content script into Tekmetric pages
- `https://shop.tekmetric.com/*`: Access production Tekmetric
- `https://api.tekmetric.com/*`: Make API calls to Tekmetric

## Troubleshooting

### Side panel not opening
- Ensure you're on a `shop.tekmetric.com` page
- Check that the extension is enabled in `chrome://extensions/`

### No data appearing
- Verify Tekmetric API credentials in backend environment
- Check browser console for error messages
- Ensure content script is injecting (check Console for `[AI Sales Assistant]` logs)

### Script generation failing
- Verify `OPENAI_API_KEY` is set in backend environment
- Check network requests in DevTools Network tab
- Ensure backend is running and accessible

## Support

For issues or questions, contact your system administrator or refer to the main project documentation.
