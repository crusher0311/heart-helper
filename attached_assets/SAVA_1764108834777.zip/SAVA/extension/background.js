// Background service worker for Chrome extension
// Handles side panel opening and message passing

// Open side panel when extension icon is clicked
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Background] Received message:', message);
  
  if (message.type === 'TEKMETRIC_DATA') {
    console.log('[Background] 📦 Received Tekmetric data from content script');
    console.log('[Background] 📊 Data preview:', {
      roNumber: message.data?.roNumber,
      customerName: message.data?.customerName,
      repairOrdersCount: message.data?.repairOrders?.length || 0
    });
    
    // Forward to ALL side panels that might be open
    chrome.runtime.sendMessage({
      type: 'FORWARD_TEKMETRIC_DATA',
      data: message.data
    }).catch(err => {
      console.log('[Background] ⚠️ No sidepanel listeners (sidepanel may not be open yet)');
    });
  }
  
  if (message.type === 'AUTH_TOKEN_CAPTURED') {
    console.log('[Background] 🔑 Captured Tekmetric auth token');
    chrome.storage.local.set({ 
      tekmetricAuthToken: message.token,
      tokenCapturedAt: Date.now()
    });
  }
  
  if (message.type === 'OPEN_CONCERN_INTAKE') {
    console.log('[Background] 🎯 Opening sidepanel to Concern Intake mode');
    
    // Get the tab that sent the message
    const tabId = sender.tab?.id;
    if (tabId) {
      // Open sidepanel for this tab
      chrome.sidePanel.open({ tabId }).then(() => {
        console.log('[Background] ✅ Sidepanel opened');
        
        // Send message to sidepanel to switch to concern intake tab
        setTimeout(() => {
          chrome.runtime.sendMessage({
            type: 'SWITCH_TO_CONCERN_INTAKE'
          }).catch(err => {
            console.log('[Background] ⚠️ Could not switch tab (sidepanel may still be loading)');
          });
        }, 500);
      }).catch(err => {
        console.error('[Background] ❌ Failed to open sidepanel:', err);
      });
    }
  }
  
  if (message.type === 'GET_API_CONFIG') {
    // Retrieve API configuration from extension storage
    chrome.storage.sync.get(['apiUrl', 'organizationId'], (result) => {
      sendResponse({
        apiUrl: result.apiUrl || 'https://105eb3e1-eaaa-4964-b7c6-9602d4c217ed-00-1t1pqb7mrp2pz.janeway.replit.dev',
        organizationId: result.organizationId || 'default-org'
      });
    });
    return true; // Keep channel open for async response
  }
  
  if (message.type === 'SAVE_API_CONFIG') {
    // Save API configuration to extension storage
    chrome.storage.sync.set({
      apiUrl: message.apiUrl,
      organizationId: message.organizationId
    }, () => {
      sendResponse({ success: true });
    });
    return true;
  }
});

// Initialize side panel for Tekmetric pages
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url?.includes('shop.tekmetric.com')) {
    console.log('[Background] Tekmetric page detected');
    
    // Enable side panel for this tab
    chrome.sidePanel.setOptions({
      tabId,
      enabled: true
    });
    
    // Content script will be injected automatically via manifest.json
  }
});

console.log('[Background] Service worker initialized with token interceptor');
