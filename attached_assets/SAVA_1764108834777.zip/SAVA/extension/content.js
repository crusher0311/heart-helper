// Content script that injects into Tekmetric pages
// Extracts repair order, customer, and vehicle data from the DOM

console.log('='.repeat(50));
console.log('[AI Sales Assistant] Content script loaded!');
console.log('[AI Sales Assistant] Current URL:', window.location.href);
console.log('[AI Sales Assistant] Page title:', document.title);
console.log('='.repeat(50));

// Intercept both fetch AND XMLHttpRequest to capture auth token
(function() {
  // Intercept fetch requests
  const originalFetch = window.fetch;
  window.fetch = function(...args) {
    const [url, options] = args;
    
    // Check if this is a Tekmetric API request
    if (url && (url.includes('api.tekmetric.com') || url.includes('sandbox.tekmetric.com') || url.includes('shop.tekmetric.com/api'))) {
      const headers = options?.headers || {};
      const authHeader = headers['X-Authorization'] || headers['Authorization'] || 
                        headers['x-authorization'] || headers['authorization'];
      
      if (authHeader) {
        console.log('[Content Script] 🔑 Captured auth token from FETCH request');
        
        // Cache token in local storage with timestamp
        chrome.storage.local.set({
          'tekmetric_auth_token': authHeader,
          'tekmetric_auth_timestamp': Date.now()
        });
        
        chrome.runtime.sendMessage({
          type: 'AUTH_TOKEN_CAPTURED',
          token: authHeader
        });
      }
    }
    
    return originalFetch.apply(this, args);
  };
  
  // Intercept XMLHttpRequest
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;
  const originalXHRSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
  
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._url = url;
    this._headers = {};
    return originalXHROpen.apply(this, [method, url, ...rest]);
  };
  
  XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
    this._headers = this._headers || {};
    this._headers[header] = value;
    
    // Capture token from headers
    if (this._url && (this._url.includes('api.tekmetric.com') || this._url.includes('sandbox.tekmetric.com') || this._url.includes('shop.tekmetric.com/api'))) {
      if (header === 'X-Authorization' || header === 'Authorization' || header === 'x-authorization' || header === 'authorization') {
        console.log('[Content Script] 🔑 Captured auth token from XHR request to:', this._url);
        console.log('[Content Script] 🔑 Header name:', header, 'Value preview:', value.substring(0, 20) + '...');
        
        // Cache token in local storage with timestamp
        chrome.storage.local.set({
          'tekmetric_auth_token': value,
          'tekmetric_auth_timestamp': Date.now()
        });
        
        chrome.runtime.sendMessage({
          type: 'AUTH_TOKEN_CAPTURED',
          token: value
        });
      }
    }
    
    return originalXHRSetRequestHeader.apply(this, [header, value]);
  };
  
  console.log('[Content Script] ✅ Fetch + XHR interceptors installed');
})();

// Fetch complete RO data from Tekmetric API
async function fetchTekmetricROData(roNumber, authToken) {
  try {
    console.log('[Content Script] 📡 Fetching RO data from Tekmetric API:', roNumber);
    
    const response = await fetch(`https://api.tekmetric.com/api/v1/repair-orders/${roNumber}`, {
      headers: {
        'X-Authorization': authToken,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      console.error('[Content Script] ❌ API request failed:', response.status, response.statusText);
      
      // If 401, token expired - clear cache
      if (response.status === 401) {
        console.log('[Content Script] Token expired, clearing cache');
        chrome.storage.local.remove(['tekmetric_auth_token', 'tekmetric_auth_timestamp']);
      }
      return null;
    }
    
    const roData = await response.json();
    console.log('[Content Script] ✅ Received complete RO data from API');
    console.log('[Content Script] API Response:', JSON.stringify(roData, null, 2));
    
    // Extract RO number from API response or page title
    const displayRONumber = roData.number || roData.displayId || roData.id?.toString() || roNumber;
    
    // Transform API data to our format
    // Tekmetric API returns: jobs[] array with laborAmount, partsAmount, total
    const jobs = roData.jobs || [];
    console.log('[Content Script] Processing', jobs.length, 'jobs from API');
    
    const repairOrders = jobs.map(job => {
      const price = job.total || (job.laborAmount + job.partsAmount) || 0;
      console.log(`[Content Script] Job: "${job.name}" - Labor: $${job.laborAmount}, Parts: $${job.partsAmount}, Total: $${price}`);
      
      return {
        service: job.name || job.description || 'Unnamed Service',
        priority: job.authorization === 'Authorized' ? 'approved' : 
                 (job.authorization === 'Declined' ? 'declined' : 'recommended'),
        price: price,
        description: job.description || job.customerConcern || '',
        laborPrice: job.laborAmount || 0,
        partsPrice: job.partsAmount || 0
      };
    });
    
    console.log('[Content Script] ✅ Transformed', repairOrders.length, 'repair orders');
    console.log('[Content Script] Total RO amount:', repairOrders.reduce((sum, ro) => sum + ro.price, 0));
    
    return {
      roNumber: displayRONumber,
      customerId: roData.customerId,
      vehicleId: roData.vehicleId,
      customerName: `${roData.customer?.firstName || ''} ${roData.customer?.lastName || ''}`.trim() || null,
      vehicleInfo: roData.vehicle ? 
        `${roData.vehicle.year || ''} ${roData.vehicle.make || ''} ${roData.vehicle.model || ''}`.trim() :
        null,
      mileage: roData.vehicle?.mileage || null,
      serviceWriter: null, // Not in API response
      technician: null, // Extract from jobs if needed
      concerns: roData.customerConcerns || [],
      repairOrders: repairOrders
    };
  } catch (error) {
    console.error('[Content Script] ❌ Error fetching from API:', error);
    return null;
  }
}

// Extract data from Tekmetric repair order page (DOM scraping fallback)
async function extractTekmetricDataFromDOM() {
  console.log('[Content Script] Extracting Tekmetric data from DOM:', window.location.href);
  
  const data = {
    roNumber: null,
    customerId: null,
    vehicleId: null,
    customerName: null,
    vehicleInfo: null,
    mileage: null,
    serviceWriter: null,
    technician: null,
    concerns: [],
    repairOrders: []
  };

  try {
    // Extract from page title: "RO #141042: Janes Hayden's 2011 Honda CR-Z EX"
    const h1Element = document.querySelector('h1');
    const pageTitle = h1Element?.textContent?.trim() || document.title || '';
    console.log('[Content Script] H1 element found:', !!h1Element);
    console.log('[Content Script] Page title from H1:', h1Element?.textContent);
    console.log('[Content Script] Document title:', document.title);
    console.log('[Content Script] Using title:', pageTitle);
    
    // Extract RO number from page title (display ID, not internal URL ID)
    const roNumberMatch = pageTitle.match(/RO #?(\d+)/i);
    if (roNumberMatch) {
      data.roNumber = roNumberMatch[1];
      console.log('[Content Script] ✅ RO Number from title:', data.roNumber);
    } else {
      // Fallback to URL if not found in title
      const url = window.location.href;
      const roMatch = url.match(/repair-orders\/(\d+)/);
      if (roMatch) {
        data.roNumber = roMatch[1];
        console.log('[Content Script] RO Number from URL (fallback):', data.roNumber);
      }
    }
    
    // Try multiple patterns to extract customer and vehicle
    if (pageTitle.includes(':') && pageTitle.includes("'s")) {
      const afterColon = pageTitle.split(':')[1]?.trim() || '';
      const parts = afterColon.split("'s");
      data.customerName = parts[0]?.trim() || null;
      data.vehicleInfo = parts[1]?.trim() || null;
      console.log('[Content Script] Extracted from title - customer:', data.customerName, 'vehicle:', data.vehicleInfo);
    } else if (pageTitle.includes(':')) {
      // Alternative pattern without 's
      const afterColon = pageTitle.split(':')[1]?.trim() || '';
      data.customerName = afterColon.split(/\d{4}/)[0]?.trim() || null;
      data.vehicleInfo = afterColon.match(/\d{4}.*/)?.[0]?.trim() || null;
      console.log('[Content Script] Extracted alt pattern - customer:', data.customerName, 'vehicle:', data.vehicleInfo);
    }
    
    // If still no data, try to get from document title as fallback
    if (!data.customerName && !data.vehicleInfo && document.title.includes(':')) {
      const docTitle = document.title;
      if (docTitle.includes("'s")) {
        const afterColon = docTitle.split(':')[1]?.trim() || '';
        const parts = afterColon.split("'s");
        data.customerName = parts[0]?.trim() || null;
        data.vehicleInfo = parts[1]?.trim() || null;
        console.log('[Content Script] Extracted from document.title - customer:', data.customerName, 'vehicle:', data.vehicleInfo);
      }
    }
    
    // Extract service writer, technician, and mileage from sidebar
    const allElements = document.querySelectorAll('div, span, label, dt, dd');
    let mileage = null;
    
    // Find Service Writer
    for (let i = 0; i < allElements.length; i++) {
      const text = allElements[i].textContent?.trim();
      if (text === 'Service Writer' && allElements[i + 1]) {
        data.serviceWriter = allElements[i + 1].textContent?.trim();
        console.log('[Content Script] Service Writer:', data.serviceWriter);
        break;
      }
    }
    
    // Find Technician
    for (let i = 0; i < allElements.length; i++) {
      const text = allElements[i].textContent?.trim();
      if (text === 'Technician' && allElements[i + 1]) {
        data.technician = allElements[i + 1].textContent?.trim();
        console.log('[Content Script] Technician:', data.technician);
        break;
      }
    }
    
    // Find Mileage (look for "In:" or "Out:" labels)
    for (let i = 0; i < allElements.length; i++) {
      const text = allElements[i].textContent?.trim();
      if ((text === 'In:' || text === 'Out:') && allElements[i + 1]) {
        const mileageText = allElements[i + 1].textContent?.trim();
        if (mileageText && /^\d{1,3}(,\d{3})*$/.test(mileageText)) {
          mileage = mileageText.replace(/,/g, '');
          console.log('[Content Script] Mileage:', mileage);
          break;
        }
      }
    }
    
    // Extract services/jobs from visible sections (Customer Concerns, Technician Concerns, etc.)
    console.log('[Content Script] Extracting services from concerns sections...');
    
    // First, try to scroll to load any lazy-loaded content
    window.scrollTo(0, document.body.scrollHeight);
    await new Promise(resolve => setTimeout(resolve, 500));
    window.scrollTo(0, 0);
    
    const seenServices = new Set();
    
    // DEBUG: Save a sample of the page HTML to understand structure
    const bodyHTML = document.body.innerHTML;
    const sparkIndex = bodyHTML.toLowerCase().indexOf('spark plug');
    if (sparkIndex > -1) {
      const sample = bodyHTML.substring(Math.max(0, sparkIndex - 200), sparkIndex + 400);
      console.log('[Content Script] 🔍 HTML around "spark plug":', sample);
    }
    
    // Look for concern items in the page
    const allDivs = document.querySelectorAll('div, li, tr');
    
    allDivs.forEach((element) => {
      const text = element.textContent?.trim() || '';
      
      // Skip if too short or too long
      if (text.length < 15 || text.length > 200) return;
      
      // Look for service-like patterns
      const isServicePattern = (
        // Contains service keywords
        /spark plug|oil change|brake|filter|tire|battery|fluid|transmission|service|inspection|replace|repair/i.test(text) &&
        // Not a section header
        !/^(customer concerns|technician concerns|vehicle issues|declined jobs)$/i.test(text) &&
        // Not too generic
        text.length > 15
      );
      
      if (isServicePattern && !seenServices.has(text.toLowerCase())) {
        // Clean up the text
        let serviceName = text
          .split('\n')[0]  // Take first line
          .replace(/^Finding\s*/i, '')
          .replace(/^Sort By:.*$/i, '')
          .replace(/\s{2,}/g, ' ')
          .trim();
        
        if (serviceName.length >= 15 && serviceName.length < 150 && !seenServices.has(serviceName.toLowerCase())) {
          seenServices.add(serviceName.toLowerCase());
          console.log('[Content Script] ✅ Found service-like text in concerns:', serviceName);
          data.concerns.push(serviceName);
        }
      }
    });
    
    console.log('[Content Script] Total concerns captured:', data.concerns.length);
    console.log('[Content Script] repairOrders before conversion:', data.repairOrders.length);
    
    // Always convert concerns to repair orders (filter and clean)
    if (data.concerns.length > 0) {
      console.log('[Content Script] Converting concerns to repair orders...');
      
      // Filter for main service names only (not detail lines)
      const mainServices = data.concerns.filter(concern => {
        const clean = concern.trim();
        return (
          clean.length >= 15 &&
          clean.length < 80 &&  // Shorter to avoid detail lines
          !clean.includes('Summary') &&
          !clean.includes('Inspection') &&
          !clean.includes('Payment') &&
          !clean.toLowerCase().includes('approved on') &&
          !clean.includes('TOM K.') &&
          !clean.includes('JACOB') &&
          !clean.includes('KEAGLE') &&
          !clean.includes('PADAL') &&
          !clean.startsWith('LaborTechnician') &&
          !clean.startsWith('PartQtyCost') &&
          !clean.includes('All 1 Received') &&
          !clean.includes('All 4 Received') &&
          !clean.includes('ReceivedNAPA') &&
          !clean.includes('ReceivedAutoZone') &&
          !/\d{4,}/.test(clean) &&  // No part numbers (4+ digits)
          // Must have service-related keywords
          (/spark plug|oil change|brake|air filter|cabin filter|tire|tpms|battery|transmission|cvt|bg|muffler|exhaust/i.test(clean))
        );
      });
      
      console.log('[Content Script] Found', mainServices.length, 'main services');
      
      // Deduplicate similar service names aggressively
      const uniqueServices = [];
      const seen = new Set();
      
      mainServices.forEach(service => {
        const normalized = service.toLowerCase()
          .replace(/[^a-z0-9\s]/g, '') // Remove special chars
          .replace(/\s+/g, ' ')
          .trim();
        
        // Check if we already have a very similar service
        let isDuplicate = false;
        for (const existing of seen) {
          // If 80% of words match, consider it a duplicate
          const words1 = normalized.split(' ');
          const words2 = existing.split(' ');
          const commonWords = words1.filter(w => words2.includes(w)).length;
          const similarity = commonWords / Math.max(words1.length, words2.length);
          
          if (similarity > 0.7) {
            isDuplicate = true;
            break;
          }
        }
        
        if (!isDuplicate) {
          seen.add(normalized);
          uniqueServices.push(service);
        }
      });
      
      console.log('[Content Script] After dedup:', uniqueServices.length, 'unique services');
      
      // Extract prices for unique services
      uniqueServices.forEach(serviceName => {
        const pageText = document.body.textContent || '';
        const serviceIndex = pageText.indexOf(serviceName);
        let price = 0;
        
        if (serviceIndex > -1) {
          // Use smaller window (150 chars) to avoid grabbing other service prices
          const nearbyText = pageText.substring(serviceIndex, serviceIndex + 150);
          const allPrices = nearbyText.match(/\$[\d,]+\.?\d*/g);
          
          if (allPrices && allPrices.length > 0) {
            // Sum all prices found (labor + parts)
            price = allPrices
              .map(p => parseFloat(p.replace(/[$,]/g, '')))
              .reduce((sum, p) => sum + p, 0);
          }
        }
        
        console.log('[Content Script] ✅ Repair order:', serviceName, '($' + price + ')');
        
        data.repairOrders.push({
          service: serviceName,
          priority: 'recommended',
          price: price,
          description: ''
        });
      });
      
      console.log('[Content Script] Created', data.repairOrders.length, 'repair orders from concerns');
      
      // Sort by price (highest first) and service name quality
      data.repairOrders.sort((a, b) => {
        // Prioritize services with prices
        if (a.price > 0 && b.price === 0) return -1;
        if (a.price === 0 && b.price > 0) return 1;
        
        // Among priced services, sort by price descending
        if (a.price !== b.price) return b.price - a.price;
        
        // Among same price, prefer shorter names (cleaner)
        return a.service.length - b.service.length;
      });
      
      console.log('[Content Script] Sorted repair orders (top 5):', 
        data.repairOrders.slice(0, 5).map(ro => `${ro.service} ($${ro.price})`));
    }
    
    // Add mileage to vehicleInfo if found
    if (mileage && data.vehicleInfo) {
      data.mileage = mileage;
      console.log('[Content Script] Added mileage to vehicle info:', mileage);
    }
    
  } catch (error) {
    console.error('[Content Script] Error extracting data:', error);
  }

  console.log('[Content Script] Final extracted data from DOM:', data);
  return data;
}

// Fetch RO data from our backend (which uses Tekmetric API server-side)
async function fetchFromBackend(roNumber) {
  try {
    console.log('[Content Script] 🔄 Fetching RO data from backend API:', roNumber);
    
    // Get the backend URL from extension storage or use default
    const backendUrl = 'https://105eb3e1-eaaa-4964-b7c6-9602d4c217ed-00-1t1pqb7mrp2pz.janeway.replit.dev';
    
    const response = await fetch(`${backendUrl}/api/tekmetric/repair-orders/${roNumber}`);
    
    if (!response.ok) {
      console.error('[Content Script] ❌ Backend API request failed:', response.status, response.statusText);
      return null;
    }
    
    const roData = await response.json();
    console.log('[Content Script] ✅ Received RO data from backend');
    console.log('[Content Script] Backend API Response:', JSON.stringify(roData, null, 2));
    
    // Backend already returns parsed data in our format!
    // Just use it directly instead of re-parsing
    console.log('[Content Script] ✅ Backend returned', (roData.repairOrders || []).length, 'repair orders');
    
    if (roData.repairOrders && roData.repairOrders.length > 0) {
      const total = roData.repairOrders.reduce((sum, ro) => sum + ro.price, 0);
      console.log('[Content Script] Total RO amount:', total.toFixed(2));
      roData.repairOrders.forEach(ro => {
        console.log(`[Content Script] - ${ro.service}: $${ro.price} (${ro.priority})`);
      });
    }
    
    // Backend returns data in our exact format, just return it
    return roData;
  } catch (error) {
    console.error('[Content Script] ❌ Error fetching from backend:', error);
    return null;
  }
}

// Main extraction function that tries multiple approaches
async function extractTekmetricData() {
  // Extract RO number from URL first
  const url = window.location.href;
  const roMatch = url.match(/repair-orders\/(\d+)/);
  
  if (!roMatch) {
    console.log('[Content Script] Not on a repair order page');
    return extractTekmetricDataFromDOM();
  }
  
  const urlId = roMatch[1];
  console.log('[Content Script] 🎯 URL ID from URL:', urlId);
  
  // Also extract display RO number from page title
  const title = document.title;
  const displayRoMatch = title.match(/RO #(\d+)/);
  const displayRoNumber = displayRoMatch ? displayRoMatch[1] : null;
  console.log('[Content Script] 🎯 Display RO Number from title:', displayRoNumber);
  
  // Strategy 1: Try backend API with display RO number first (more likely to work)
  if (displayRoNumber) {
    console.log('[Content Script] 📡 Strategy 1a: Trying backend API with display RO number...');
    const backendData = await fetchFromBackend(displayRoNumber);
    if (backendData) {
      console.log('[Content Script] ✅ SUCCESS: Using backend API data with display RO (most accurate!)');
      return backendData;
    }
    console.log('[Content Script] ⚠️ Backend API with display RO failed...');
  }
  
  // Strategy 1b: Try backend API with URL ID as fallback
  console.log('[Content Script] 📡 Strategy 1b: Trying backend API with URL ID...');
  const backendData = await fetchFromBackend(urlId);
  if (backendData) {
    console.log('[Content Script] ✅ SUCCESS: Using backend API data with URL ID (most accurate!)');
    return backendData;
  }
  console.log('[Content Script] ⚠️ Backend API with URL ID failed, trying next strategy...');
  
  // Strategy 2: Try browser's cached auth token
  return new Promise((resolve) => {
    chrome.storage.local.get(['tekmetric_auth_token', 'tekmetric_auth_timestamp'], async (result) => {
      const token = result.tekmetric_auth_token;
      const timestamp = result.tekmetric_auth_timestamp;
      
      if (token) {
        // Check if token is not too old (4 hours = 14400000 ms)
        const tokenAge = Date.now() - (timestamp || 0);
        if (tokenAge < 14400000) {
          console.log('[Content Script] 📡 Strategy 2: Trying cached browser auth token...');
          
          // Try display RO number first, then URL ID
          const idsToTry = displayRoNumber ? [displayRoNumber, urlId] : [urlId];
          
          for (const id of idsToTry) {
            const apiData = await fetchTekmetricROData(id, token);
            if (apiData) {
              console.log(`[Content Script] ✅ SUCCESS: Using browser token API data with ID ${id}`);
              resolve(apiData);
              return;
            }
          }
          
          console.log('[Content Script] ⚠️ Browser token API failed for all IDs, clearing cache');
          chrome.storage.local.remove(['tekmetric_auth_token', 'tekmetric_auth_timestamp']);
        } else {
          console.log('[Content Script] ⚠️ Cached token too old, clearing');
          chrome.storage.local.remove(['tekmetric_auth_token', 'tekmetric_auth_timestamp']);
        }
      }
      
      // Strategy 3: Fallback to DOM scraping (last resort, prices may be inaccurate)
      console.log('[Content Script] 📄 Strategy 3: Falling back to DOM scraping (PRICES MAY BE INACCURATE)');
      resolve(extractTekmetricDataFromDOM());
    });
  });
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Content Script] Received message:', message);
  
  if (message.type === 'GET_TEKMETRIC_DATA') {
    // Handle async extraction
    extractTekmetricData().then(data => {
      console.log('[Content Script] Sending response with repairOrders count:', data?.repairOrders?.length || 0);
      console.log('[Content Script] Sending response with concerns count:', data?.concerns?.length || 0);
      console.log('[Content Script] About to send response:', data);
      sendResponse(data);
    });
    return true; // Keep channel open for async response
  }
  
  if (message.type === 'SEND_TO_TEKMETRIC') {
    console.log('[Content Script] Injecting cleaned conversation to Tekmetric');
    
    // Inject with revert detection - returns 'success', 'missing', or 'reverted'
    injectConversationToTekmetric(message.conversationText, (result) => {
      sendResponse({ result });
    });
    
    return true; // Keep channel open for async response
  }
  
  return true;
});

// Send data to background script when page loads
async function sendDataToExtension() {
  console.log('[Content Script] ⚡ sendDataToExtension called for:', window.location.href);
  const data = await extractTekmetricData();
  console.log('[Content Script] ⚡ Extracted data:', {
    hasRoNumber: !!data.roNumber,
    hasCustomerName: !!data.customerName,
    roNumber: data.roNumber,
    customerName: data.customerName
  });
  
  if (data.roNumber || data.customerName) {
    console.log('[Content Script] ✅ Sending data to background script');
    chrome.runtime.sendMessage({
      type: 'TEKMETRIC_DATA',
      data: data
    });
  } else {
    console.warn('[Content Script] ⚠️ NOT sending data - no RO number or customer name found');
  }
}

// Watch for navigation changes in Tekmetric SPA
let lastUrl = window.location.href;
setInterval(() => {
  if (window.location.href !== lastUrl) {
    lastUrl = window.location.href;
    console.log('[AI Sales Assistant] Page navigation detected');
    setTimeout(sendDataToExtension, 1000); // Wait for page to render
  }
}, 500);

// Initial load
setTimeout(sendDataToExtension, 2000);

// ========================================
// CONCERN INTAKE DOM INJECTION
// ========================================

// Inject "Add AI Concern" button near concern/description textareas
function injectAddConcernButton() {
  console.log('[Content Script] Checking for concern/description textareas to inject button...');
  
  // Check if we're on a repair order or appointment page
  const isRepairOrder = window.location.href.includes('/repair-orders/');
  const isAppointment = window.location.href.includes('/appointments/');
  
  if (!isRepairOrder && !isAppointment) {
    console.log('[Content Script] Not on repair order or appointment page, skipping button injection');
    return;
  }
  
  // Look for concern or description textarea
  const concernTextarea = document.querySelector('textarea#concern, textarea[name="concern"]');
  const descriptionTextarea = document.querySelector('textarea#description, textarea[name="description"]');
  const targetTextarea = concernTextarea || descriptionTextarea;
  
  if (!targetTextarea) {
    console.log('[Content Script] No concern/description textarea found on page');
    return;
  }
  
  // Check if button already exists
  if (document.getElementById('ai-concern-button')) {
    console.log('[Content Script] Add AI Concern button already exists');
    return;
  }
  
  console.log('[Content Script] Found textarea, injecting Add AI Concern button');
  
  // Create button
  const button = document.createElement('button');
  button.id = 'ai-concern-button';
  button.type = 'button';
  button.textContent = '✨ Add AI Concern';
  button.style.cssText = `
    margin-top: 8px;
    padding: 8px 16px;
    background-color: #3b82f6;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    transition: background-color 0.2s;
  `;
  
  // Add hover effect
  button.addEventListener('mouseenter', () => {
    button.style.backgroundColor = '#2563eb';
  });
  button.addEventListener('mouseleave', () => {
    button.style.backgroundColor = '#3b82f6';
  });
  
  // Add click handler
  button.addEventListener('click', () => {
    console.log('[Content Script] Add AI Concern button clicked, opening sidepanel');
    chrome.runtime.sendMessage({
      type: 'OPEN_CONCERN_INTAKE'
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('[Content Script] ❌ Failed to send message:', chrome.runtime.lastError);
      } else {
        console.log('[Content Script] ✅ Message sent successfully');
      }
    });
  });
  
  // Insert button after textarea
  targetTextarea.parentNode.insertBefore(button, targetTextarea.nextSibling);
  console.log('[Content Script] ✅ Add AI Concern button injected successfully');
}

// Inject cleaned conversation with revert detection
// Returns: 'success', 'missing', or 'reverted'
function injectConversationToTekmetric(conversationText, callback) {
  console.log('[Content Script] Injecting conversation:', conversationText.substring(0, 100) + '...');
  
  try {
    // Find textarea
    let targetTextarea = document.querySelector('textarea#concern, textarea[name="concern"]');
    if (!targetTextarea) {
      targetTextarea = document.querySelector('textarea#description, textarea[name="description"]');
    }
    
    if (!targetTextarea) {
      console.error('[Content Script] No concern/description textarea found');
      callback('missing');
      return;
    }
    
    if (!targetTextarea.isConnected) {
      console.error('[Content Script] Textarea not connected to DOM');
      callback('missing');
      return;
    }
    
    // Set value and dispatch events
    targetTextarea.value = conversationText;
    if (targetTextarea.value !== conversationText) {
      console.error('[Content Script] Failed to set value');
      callback('missing');
      return;
    }
    
    try {
      targetTextarea.dispatchEvent(new Event('input', { bubbles: true }));
      targetTextarea.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (eventError) {
      console.error('[Content Script] Event dispatch failed:', eventError);
    }
    
    // Monitor for reverts over 1.5 second window
    const monitorDuration = 1500;
    const pollInterval = 200;
    let reverted = false;
    let observer = null;
    
    // MutationObserver to detect DOM-level changes
    const observerConfig = { attributes: true, childList: false, subtree: false };
    observer = new MutationObserver(() => {
      const current = document.querySelector('textarea#concern, textarea[name="concern"]') || 
                      document.querySelector('textarea#description, textarea[name="description"]');
      if (!current || current.value !== conversationText) {
        console.warn('[Content Script] MutationObserver detected value change');
        reverted = true;
      }
    });
    
    try {
      observer.observe(targetTextarea, observerConfig);
    } catch (obsError) {
      console.warn('[Content Script] MutationObserver failed to attach:', obsError);
    }
    
    // Polling to detect React-controlled field snapbacks
    let pollAttempts = 0;
    const maxPolls = Math.ceil(monitorDuration / pollInterval);
    
    const pollForReverts = () => {
      pollAttempts++;
      
      // Re-query DOM for fresh reference
      const freshTextarea = document.querySelector('textarea#concern, textarea[name="concern"]') || 
                            document.querySelector('textarea#description, textarea[name="description"]');
      
      if (!freshTextarea || !freshTextarea.isConnected) {
        console.error('[Content Script] Textarea disappeared during monitoring');
        if (observer) observer.disconnect();
        callback('missing');
        return;
      }
      
      // Check if value was reverted
      if (freshTextarea.value !== conversationText) {
        console.error('[Content Script] React reverted value on poll ' + pollAttempts);
        console.error('[Content Script] This is a React-controlled field that rejects external changes');
        if (observer) observer.disconnect();
        callback('reverted');
        return;
      }
      
      // Continue monitoring or succeed
      if (pollAttempts < maxPolls && !reverted) {
        setTimeout(pollForReverts, pollInterval);
      } else {
        if (observer) observer.disconnect();
        
        if (reverted) {
          console.error('[Content Script] Value was reverted during monitoring window');
          callback('reverted');
        } else {
          console.log('[Content Script] ✅ Value persisted through ' + monitorDuration + 'ms monitoring');
          
          // Visual feedback
          try {
            freshTextarea.scrollIntoView({ behavior: 'smooth', block: 'center' });
            const originalBorder = freshTextarea.style.border;
            freshTextarea.style.border = '2px solid #10b981';
            setTimeout(() => {
              if (freshTextarea.isConnected) {
                freshTextarea.style.border = originalBorder;
              }
            }, 2000);
          } catch (visualError) {
            console.warn('[Content Script] Visual feedback failed:', visualError);
          }
          
          callback('success');
        }
      }
    };
    
    // Start monitoring after animation frame
    requestAnimationFrame(() => {
      setTimeout(pollForReverts, pollInterval);
    });
    
  } catch (error) {
    console.error('[Content Script] ❌ Injection error:', error);
    callback('missing');
  }
}

// Set up mutation observer to detect DOM changes and inject button
const observer = new MutationObserver((mutations) => {
  // Debounce - only check every 500ms
  if (observer.checkTimeout) return;
  observer.checkTimeout = setTimeout(() => {
    injectAddConcernButton();
    observer.checkTimeout = null;
  }, 500);
});

// Start observing after a short delay to let page load
setTimeout(() => {
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Initial injection attempt
  injectAddConcernButton();
  
  console.log('[Content Script] 🔍 Mutation observer started for concern button injection');
}, 2000);

console.log('[AI Sales Assistant] Content script initialized');
