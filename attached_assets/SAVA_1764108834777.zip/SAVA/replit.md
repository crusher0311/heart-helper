# AI Sales Assistant for Automotive Service Advisors

## Overview

An AI-powered sales assistant application designed for automotive service advisors working with Tekmetric. The system generates personalized sales scripts for customer interactions, manages objection handling responses, and provides a training library to improve AI-generated content. The application features a web-based admin interface for managing training data and a Chrome extension side panel (400px wide) for real-time script generation during customer calls.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack**: React with TypeScript, built using Vite as the build tool and bundler.

**UI Framework**: Implements shadcn/ui component library (New York style variant) built on Radix UI primitives with Tailwind CSS for styling. The design follows Material Design principles adapted for automotive industry professionalism with a custom color system based on neutral tones.

**State Management**: TanStack Query (React Query) for server state management with aggressive caching strategies (staleTime: Infinity) to minimize API calls. No global client state management library - relies on React's built-in state and query cache.

**Routing**: Wouter for lightweight client-side routing with the following main routes:
- `/` - Dashboard (overview and metrics, includes Chrome extension download)
- `/training` - Script training examples management
- `/objections` - Objection response library
- `/settings` - Organization and integration settings (includes phone answer script configuration)
- `/analytics` - Performance metrics and ROI tracking
- `/extension` - Chrome extension preview/simulator

**Design System**: Custom Tailwind configuration with HSL-based color variables for theme support. Typography uses Inter font from Google Fonts. Spacing follows a strict 2/4/6/8 unit system. The extension side panel is constrained to 400px width to match Chrome's side panel specifications.

### Backend Architecture

**Runtime**: Node.js with Express.js framework, written in TypeScript and compiled using esbuild for production.

**API Structure**: RESTful API with the following main endpoints:
- `GET/POST /api/training` - Training examples CRUD
- `GET/POST/DELETE /api/objections` - Objection responses CRUD
- `POST /api/scripts/generate` - AI script generation
- `GET /api/organizations/current` - Fetch current organization settings
- `PATCH /api/organizations/current` - Update organization settings (phone answer script, etc.)
- `GET /api/extension/download` - Download Chrome extension as ZIP file

**Multi-tenancy**: Organization-based isolation using `organizationId` foreign keys. Currently defaults to a "default-org" organization, with session-based organization resolution planned for production.

**Error Handling**: Centralized error handling with request/response logging middleware. API errors return JSON with error messages. Client-side errors caught by React Query and displayed via toast notifications.

### Data Storage

**Database**: PostgreSQL via Neon serverless (WebSocket-based connection pooling).

**ORM**: Drizzle ORM for type-safe database queries and schema management. Schema defined in `shared/schema.ts` with automatic TypeScript type generation.

**Schema Design**:
- `organizations` - Multi-tenant organization data (id, name, phoneAnswerScript, createdAt)
- `trainingExamples` - AI learning examples with categories ("approved"/"avoid"), script types ("opening"/"repair_priority"/"closing"), and content
- `objectionResponses` - Reusable objection handling scripts categorized by type ("price"/"timing"/"trust") with active/inactive flags and sorting

**Migrations**: Drizzle Kit for schema migrations stored in `/migrations` directory. Push command (`npm run db:push`) for development schema synchronization.

### Authentication and Authorization

**Current State**: No authentication implemented in MVP. Uses hardcoded "default-org" organization ID.

**Planned Approach**: Session-based authentication with organization resolution from authenticated user context. Middleware stub exists in `getCurrentOrg()` function for future session integration.

### External Dependencies

**AI Service**: OpenAI GPT-5 API for sales script generation. Prompts are engineered with few-shot learning using approved/avoid training examples from the database. System prompt emphasizes trust-building, safety focus, and conversational tone.

**Tekmetric Integration**: Placeholder client implementation (`server/tekmetric.ts`) for fetching:
- Customer data (name, contact info)
- Vehicle information (year, make, model, mileage, VIN)
- Repair order data (services, pricing, status)

Currently returns mock data structure. Production implementation would use Tekmetric's REST API with Bearer token authentication.

**Third-party UI Libraries**:
- Radix UI - Accessible component primitives (dialogs, dropdowns, accordions, etc.)
- Lucide React - Icon system
- date-fns - Date formatting and manipulation
- cmdk - Command palette component
- Embla Carousel - Carousel component
- react-day-picker - Calendar/date picker

**Developer Tools** (Replit-specific):
- `@replit/vite-plugin-runtime-error-modal` - Development error overlay
- `@replit/vite-plugin-cartographer` - Code navigation
- `@replit/vite-plugin-dev-banner` - Development mode indicator

### Key Architectural Decisions

**Monorepo Structure**: Single repository with client, server, and shared code. Shared types and schemas in `/shared` directory accessible to both frontend (`@shared/*`) and backend. Rationale: Simplifies type safety across full stack and reduces duplication.

**Server-Side Rendering**: Not implemented. Pure SPA with client-side routing. Static files served from Express in production. Rationale: Simpler deployment, no SEO requirements for internal tool.

**API Design**: RESTful rather than GraphQL. Rationale: Simpler for CRUD operations, less overhead for small API surface area.

**Real-time Updates**: Not implemented. Uses polling via React Query's refetch mechanisms. Rationale: Sufficient for training data that changes infrequently.

**Chrome Extension Architecture**: Extension preview built into main web app at `/extension` route. Actual extension would communicate with the same backend API. Rationale: Allows testing UX without Chrome extension packaging.

**Script Generation Strategy**: Uses conversation history and approved examples for few-shot learning rather than fine-tuning. Avoids patterns are injected as negative examples. Rationale: Faster iteration, no model training overhead, easier to update based on feedback.

**Objection Handling Architecture**: Deterministic keyword-based objection detection with metadata tracking in conversation history. Each conversation entry tracks both customer objections and advisor responses. When an objection is detected (price/timing/trust), the system:
1. Marks the customer's answer with `objectionDetected` metadata
2. Automatically generates a scripted objection response
3. Marks the advisor's response question with `isObjectionResponse: true`
4. Terminates conversation after 3-4 exchanges via `shouldClose` flag

This approach ensures reliable objection handling without relying solely on LLM interpretation, while maintaining full conversation context for quality script generation.

**Styling Approach**: Utility-first CSS with Tailwind rather than CSS-in-JS or separate stylesheets. Design tokens managed via CSS custom properties. Rationale: Better performance, no runtime overhead, excellent IDE support.

## Recent Updates

### Phone Answer Script Feature (November 2025)
Added configurable phone answer script functionality for incoming caller mode:
- **Database**: Added `phoneAnswerScript` TEXT field to organizations table
- **Settings UI**: Textarea in Settings page to configure custom greeting (e.g., "Thank you for calling HEART Certified Auto Care, this is [name], how may I assist you?")
- **Display**: Script appears prominently at top of Incoming Caller panel with copy button for quick access during calls
- **Security**: Organization settings endpoints (`/api/organizations/current`) use `getCurrentOrg()` middleware to ensure proper tenant isolation

### Chrome Extension Download (November 2025)
Added one-click extension download from Dashboard:
- **Download Endpoint**: `GET /api/extension/download` serves extension files as ZIP archive

### Concern Intake Mode (November 2025)
Added third mode to Chrome extension for gathering detailed customer concerns through AI-guided conversation:

**Backend Implementation:**
- **Schemas**: Added concern-specific types to `shared/schema.ts`:
  - `ConcernQuestionResponse` - Question/answer pairs
  - `GenerateConcernQuestionsRequest/Response` - Generate follow-up questions
  - `ReviewConcernConversationRequest/Response` - Review and generate additional questions
  - `CleanConversationRequest/Response` - Clean conversation into paragraph format
- **AI Functions**: Added three OpenAI GPT-4o functions to `server/openai.ts`:
  - `generateConcernFollowUpQuestions()` - Generates 5 diagnostic follow-up questions
  - `reviewConcernConversation()` - Reviews conversation and suggests additional questions
  - `cleanConcernConversation()` - Formats conversation into natural paragraph
- **API Endpoints**: Three new routes in `server/routes.ts`:
  - `POST /api/concerns/generate-questions` - Generate initial follow-up questions
  - `POST /api/concerns/review` - Review conversation for additional questions
  - `POST /api/concerns/clean-conversation` - Clean and format conversation text

**Frontend Implementation:**
- **Component**: New `ConcernIntakePanel` component (`client/src/components/concern-intake-panel.tsx`)
  - Three-step workflow: initial → questions → finalized
  - Customer concern input with draft persistence via chrome.storage.local
  - AI-generated follow-up question display with answer recording
  - Conversation notes textarea for additional details
  - Review functionality to generate more questions based on answers
  - Finalize functionality to clean conversation into paragraph format
  - Copy-to-clipboard for cleaned conversation
  - Complete data-testid coverage for testing
- **Extension Integration**: Added "Concern Intake" tab to extension tabs
  - Updated TabsList from 2 to 3 columns
  - Follows same pattern as Sales Script and Incoming Caller modes
- **TanStack Query Integration**: Three mutations for AI operations
  - Proper loading states with isPending checks
  - Error handling with toast notifications
  - Success callbacks with user feedback
- **Draft Persistence**: Minimal chrome.storage.local implementation
  - Saves customer concern text as user types (extension context only)
  - Restores draft on component mount
  - Clears draft when generating questions or restarting
  - Gracefully handles both web preview and extension contexts

**User Workflow:**
1. Service advisor enters customer's initial concern (e.g., "Car makes grinding noise when braking")
2. AI generates 5 diagnostic follow-up questions to gather more details
3. Advisor asks customer the questions and records answers via browser prompts
4. Optional: Review conversation to get additional follow-up questions
5. Finalize conversation to clean and format as natural paragraph
6. Send to Tekmetric (automated) or copy to clipboard (manual fallback)

**Tekmetric Integration (Stage 3):**
- **DOM Injection**: Content script (`extension/content.js`) detects repair order and appointment pages via URL pattern matching
- **Button Injection**: MutationObserver auto-injects "Add AI Concern" button next to concern/description textareas
  - Targets `textarea#concern` (repair orders) and `textarea#description` (appointments)
  - Opens sidepanel to Concern Intake tab when clicked
- **Send to Tekmetric**: Automated injection of cleaned conversation with failure-aware verification
  - **Monitoring Window**: 1.5 second observation period using MutationObserver + polling (200ms intervals)
  - **Revert Detection**: Detects if Tekmetric's React framework rejects or clears the injected value
  - **Result Codes**: Returns 'success', 'missing', or 'reverted' for accurate user feedback
  - **Error Messaging**: Different toast messages for each scenario:
    - Success: "Conversation successfully inserted"
    - Reverted: "Tekmetric rejected update - please copy and paste manually"
    - Missing: "Field not found - make sure you're on correct page"
  - **Manual Fallback**: Copy button always available for manual paste workflow
- **Best-Effort Nature**: Content script DOM injection cannot guarantee persistence if Tekmetric's React code actively rejects external changes. The 1.5s monitoring window detects most rejections, but late React updates (>1.5s) may clear the field after success is reported. Manual paste fallback ensures reliability.

**Extension Distribution:**
- **Installation Instructions**: Dashboard displays step-by-step guide for Chrome extension installation
- **Extension Packaging**: Uses `archiver` library to create ZIP with all necessary files (manifest, scripts, icons, sidepanel)
- **User Experience**: Prominent card on Dashboard with download button and clear installation steps
- **Version**: 2.4.0 (includes Concern Intake + Tekmetric integration)

**Status**: Stage 1, 2, and 3 complete (UI, backend, Tekmetric integration). Stage 4 (final testing) pending user validation with real Tekmetric account.

### Security Enhancements
- Organization endpoints now enforce proper multi-tenant authorization
- Removed ability to access arbitrary organization IDs via URL parameters
- All organization operations scoped to current authenticated organization