import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ThumbsUp, ThumbsDown } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface FeedbackControlsProps {
  targetId: string;
  targetType: "conversation" | "sales-script";
  onFeedbackSubmitted?: () => void;
}

export function FeedbackControls({ targetId, targetType, onFeedbackSubmitted }: FeedbackControlsProps) {
  const { toast } = useToast();
  const [selectedOutcome, setSelectedOutcome] = useState<"success" | "failure" | null>(null);
  const [feedbackNotes, setFeedbackNotes] = useState("");
  const [showNotesInput, setShowNotesInput] = useState(false);

  const feedbackMutation = useMutation({
    mutationFn: async (data: { outcome: "success" | "failure"; feedbackNotes?: string }) => {
      const endpoint = targetType === "conversation" 
        ? `/api/conversations/${targetId}/feedback`
        : `/api/sales-scripts/${targetId}/feedback`;
      
      const response = await apiRequest("PATCH", endpoint, {
        outcome: data.outcome,
        feedbackNotes: data.feedbackNotes || null,
      });
      return await response.json();
    },
  });

  // Handle success and error states with useEffect
  useEffect(() => {
    if (feedbackMutation.isSuccess) {
      toast({
        title: "Feedback Saved",
        description: "Thank you for your feedback!",
      });
      onFeedbackSubmitted?.();
      
      // Reset state after showing success message
      setTimeout(() => {
        setSelectedOutcome(null);
        setFeedbackNotes("");
        setShowNotesInput(false);
        feedbackMutation.reset();
      }, 2000);
    }
  }, [feedbackMutation.isSuccess]);

  useEffect(() => {
    if (feedbackMutation.isError) {
      console.error("Failed to save feedback:", feedbackMutation.error);
      toast({
        title: "Save Failed",
        description: "Unable to save feedback. Please try again.",
        variant: "destructive",
      });
    }
  }, [feedbackMutation.isError]);

  const handleThumbClick = (outcome: "success" | "failure") => {
    setSelectedOutcome(outcome);
    setShowNotesInput(true);
  };

  const handleSubmit = () => {
    if (!selectedOutcome) return;
    
    feedbackMutation.mutate({
      outcome: selectedOutcome,
      feedbackNotes: feedbackNotes.trim() || undefined,
    });
  };

  const handleSkipNotes = () => {
    if (!selectedOutcome) return;
    
    feedbackMutation.mutate({
      outcome: selectedOutcome,
    });
  };

  if (feedbackMutation.isSuccess) {
    return (
      <div className="p-3 bg-primary/5 rounded border border-primary/20" data-testid="feedback-success-message">
        <p className="text-sm font-medium text-primary" data-testid="text-feedback-confirmation">
          ✓ Feedback recorded
        </p>
        <p className="text-xs text-muted-foreground mt-1" data-testid="text-feedback-outcome">
          {selectedOutcome === "success" ? "Marked as successful" : "Marked as unsuccessful"}
        </p>
      </div>
    );
  }

  return (
    <div className="p-3 bg-muted/30 rounded border">
      <p className="text-sm font-medium mb-3">How did this go?</p>
      
      {!showNotesInput ? (
        <div className="flex gap-2">
          <Button
            onClick={() => handleThumbClick("success")}
            variant="outline"
            className="flex-1"
            data-testid="button-feedback-success"
          >
            <ThumbsUp className="w-4 h-4 mr-2" />
            Success
          </Button>
          <Button
            onClick={() => handleThumbClick("failure")}
            variant="outline"
            className="flex-1"
            data-testid="button-feedback-failure"
          >
            <ThumbsDown className="w-4 h-4 mr-2" />
            Didn't Work
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            {selectedOutcome === "success" ? (
              <ThumbsUp className="w-5 h-5 text-primary" />
            ) : (
              <ThumbsDown className="w-5 h-5 text-destructive" />
            )}
            <span className="text-sm font-medium">
              {selectedOutcome === "success" ? "Successful" : "Didn't Work"}
            </span>
          </div>
          
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">
              Add notes (optional):
            </label>
            <Textarea
              value={feedbackNotes}
              onChange={(e) => setFeedbackNotes(e.target.value)}
              placeholder="What worked well or what could be improved?"
              className="min-h-[60px]"
              data-testid="input-feedback-notes"
            />
          </div>
          
          <div className="flex gap-2">
            <Button
              onClick={handleSubmit}
              className="flex-1"
              disabled={feedbackMutation.isPending}
              data-testid="button-submit-feedback"
            >
              {feedbackMutation.isPending ? "Saving..." : "Submit Feedback"}
            </Button>
            <Button
              onClick={handleSkipNotes}
              variant="outline"
              disabled={feedbackMutation.isPending}
              data-testid="button-skip-notes"
            >
              Skip Notes
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
