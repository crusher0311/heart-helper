/// <reference types="chrome"/>

import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { CopyButton } from "@/components/copy-button";
import { Skeleton } from "@/components/ui/skeleton";
import { RefreshCw, AlertCircle, Sparkles, MessageSquare, FileText } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type {
  GenerateConcernQuestionsResponse,
  ReviewConcernConversationResponse,
  CleanConversationResponse,
  ConcernQuestionResponse
} from "@shared/schema";

const STORAGE_KEY = "concern_intake_draft";

export function ConcernIntakePanel() {
  const { toast } = useToast();
  
  const [customerConcern, setCustomerConcern] = useState("");
  const [followUpQuestions, setFollowUpQuestions] = useState<string[]>([]);
  const [answeredQuestions, setAnsweredQuestions] = useState<ConcernQuestionResponse[]>([]);
  const [conversationNotes, setConversationNotes] = useState("");
  const [cleanedConversation, setCleanedConversation] = useState("");
  const [currentStep, setCurrentStep] = useState<"initial" | "questions" | "finalized">("initial");

  const isExtension = typeof chrome !== 'undefined' && chrome.storage;

  useEffect(() => {
    if (isExtension) {
      chrome.storage.local.get([STORAGE_KEY], (result: { [key: string]: any }) => {
        if (result[STORAGE_KEY]) {
          setCustomerConcern(result[STORAGE_KEY]);
        }
      });
    }
  }, [isExtension]);

  const saveDraftToStorage = (concern: string) => {
    if (isExtension) {
      if (concern.trim()) {
        chrome.storage.local.set({ [STORAGE_KEY]: concern });
      } else {
        chrome.storage.local.remove([STORAGE_KEY]);
      }
    }
  };

  const clearDraftFromStorage = () => {
    if (isExtension) {
      chrome.storage.local.remove([STORAGE_KEY]);
    }
  };

  const generateQuestionsMutation = useMutation({
    mutationFn: async (concern: string) => {
      const response = await apiRequest("POST", "/api/concerns/generate-questions", {
        customerConcern: concern
      });
      return await response.json() as GenerateConcernQuestionsResponse;
    },
    onSuccess: (data) => {
      setFollowUpQuestions(data.questions);
      setCurrentStep("questions");
      toast({
        title: "Questions Generated",
        description: `${data.questions.length} follow-up questions ready`,
      });
    },
    onError: (error) => {
      console.error("Failed to generate questions:", error);
      toast({
        title: "Generation Failed",
        description: "Unable to generate questions. Please try again.",
        variant: "destructive",
      });
    },
  });

  const reviewConversationMutation = useMutation({
    mutationFn: async (payload: {
      customerConcern: string;
      answeredQuestions: ConcernQuestionResponse[];
    }) => {
      const response = await apiRequest("POST", "/api/concerns/review", payload);
      return await response.json() as ReviewConcernConversationResponse;
    },
    onSuccess: (data) => {
      if (data.additionalQuestions.length > 0) {
        setFollowUpQuestions(data.additionalQuestions);
        toast({
          title: "Additional Questions",
          description: `${data.additionalQuestions.length} more questions suggested`,
        });
      } else {
        toast({
          title: "Review Complete",
          description: "No additional questions needed",
        });
      }
    },
    onError: (error) => {
      console.error("Failed to review conversation:", error);
      toast({
        title: "Review Failed",
        description: "Unable to review conversation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const cleanConversationMutation = useMutation({
    mutationFn: async (conversationText: string) => {
      const response = await apiRequest("POST", "/api/concerns/clean-conversation", {
        conversationText
      });
      return await response.json() as CleanConversationResponse;
    },
    onSuccess: (data) => {
      setCleanedConversation(data.cleanedConversation);
      setCurrentStep("finalized");
      toast({
        title: "Conversation Finalized",
        description: "Cleaned conversation is ready to copy",
      });
    },
    onError: (error) => {
      console.error("Failed to clean conversation:", error);
      toast({
        title: "Finalization Failed",
        description: "Unable to clean conversation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerateQuestions = () => {
    if (!customerConcern.trim()) {
      toast({
        title: "Missing Information",
        description: "Please enter a customer concern first",
        variant: "destructive",
      });
      return;
    }
    clearDraftFromStorage();
    generateQuestionsMutation.mutate(customerConcern);
  };

  const handleConcernChange = (value: string) => {
    setCustomerConcern(value);
    saveDraftToStorage(value);
  };

  const handleConcernKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Ctrl+Enter or Cmd+Enter triggers generate questions
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleGenerateQuestions();
    }
  };

  const handleAnswerQuestion = (question: string) => {
    const answer = prompt(`Customer's answer to:\n\n"${question}"`);
    if (answer !== null && answer.trim()) {
      setAnsweredQuestions([...answeredQuestions, { question, answer }]);
      setFollowUpQuestions(followUpQuestions.filter(q => q !== question));
      toast({
        title: "Answer Recorded",
        description: "Answer saved successfully",
      });
    }
  };

  const handleReviewConversation = () => {
    if (answeredQuestions.length === 0) {
      toast({
        title: "No Answers Yet",
        description: "Please answer at least one question before reviewing",
        variant: "destructive",
      });
      return;
    }
    reviewConversationMutation.mutate({
      customerConcern,
      answeredQuestions
    });
  };

  const handleFinalizeConversation = () => {
    if (!conversationNotes.trim() && answeredQuestions.length === 0) {
      toast({
        title: "No Conversation Data",
        description: "Please add conversation notes or answer questions",
        variant: "destructive",
      });
      return;
    }

    const conversationText = buildConversationText();
    cleanConversationMutation.mutate(conversationText);
  };

  const buildConversationText = (): string => {
    let text = `Customer Concern: ${customerConcern}\n\n`;
    
    if (answeredQuestions.length > 0) {
      text += "Follow-Up Questions:\n";
      answeredQuestions.forEach((qa, index) => {
        text += `${index + 1}. ${qa.question}\n   Answer: ${qa.answer}\n\n`;
      });
    }
    
    if (conversationNotes.trim()) {
      text += `Additional Notes:\n${conversationNotes}`;
    }
    
    return text;
  };

  const handleRestart = () => {
    setCustomerConcern("");
    setFollowUpQuestions([]);
    setAnsweredQuestions([]);
    setConversationNotes("");
    setCleanedConversation("");
    setCurrentStep("initial");
    clearDraftFromStorage();
  };

  const handleSendToTekmetric = () => {
    if (!cleanedConversation.trim()) {
      toast({
        title: "No Conversation",
        description: "Please finalize the conversation first",
        variant: "destructive",
      });
      return;
    }

    if (isExtension) {
      chrome.runtime.sendMessage({
        type: 'SEND_TO_TEKMETRIC',
        conversationText: cleanedConversation
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('[Concern Intake] Message error:', chrome.runtime.lastError);
          toast({
            title: "Communication Error",
            description: "Could not communicate with Tekmetric page. Make sure you're on a repair order or appointment page.",
            variant: "destructive",
          });
          return;
        }
        
        const result = response?.result;
        
        if (result === 'success') {
          toast({
            title: "Sent to Tekmetric",
            description: "Conversation successfully inserted into concern field",
          });
        } else if (result === 'reverted') {
          toast({
            title: "Tekmetric Rejected Update",
            description: "The concern field rejected the update. Please copy the text above and paste it manually into Tekmetric.",
            variant: "destructive",
          });
        } else {
          toast({
            title: "Field Not Found",
            description: "No concern/description field found. Make sure you're on a repair order or appointment page, then try copying manually.",
            variant: "destructive",
          });
        }
      });
    } else {
      toast({
        title: "Extension Only",
        description: "This feature only works in the Chrome extension. Use the copy button to copy text for manual entry.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-3">
      <Card data-testid="card-concern-intake">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Customer Concern Intake
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 p-4">
          {currentStep === "initial" && (
            <>
              <div className="space-y-4">
                <Label htmlFor="customer-concern" data-testid="label-customer-concern" className="text-base font-medium">
                  Customer Concern
                </Label>
                <Textarea
                  id="customer-concern"
                  data-testid="input-customer-concern"
                  placeholder="Example: Car is making a grinding noise when braking..."
                  value={customerConcern}
                  onChange={(e) => handleConcernChange(e.target.value)}
                  onKeyDown={handleConcernKeyDown}
                  rows={5}
                  className="resize-none text-base"
                />
                <p className="text-xs text-muted-foreground -mt-2">
                  Press Ctrl+Enter to generate questions
                </p>
              </div>
              
              <Button
                onClick={handleGenerateQuestions}
                disabled={generateQuestionsMutation.isPending || !customerConcern.trim()}
                className="w-full"
                data-testid="button-generate-questions"
              >
                {generateQuestionsMutation.isPending ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Generating Questions...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate Follow-Up Questions
                  </>
                )}
              </Button>
            </>
          )}

          {currentStep === "questions" && (
            <>
              <div className="p-5 bg-muted/30 rounded-md">
                <p className="text-sm font-medium mb-3">Original Concern:</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{customerConcern}</p>
              </div>

              {followUpQuestions.length > 0 && (
                <div className="space-y-5">
                  <Label className="text-base font-semibold">Follow-Up Questions</Label>
                  {followUpQuestions.map((question, index) => (
                    <div key={index} className="p-5 bg-muted/20 rounded-md space-y-4" data-testid={`question-${index}`}>
                      <p className="text-base leading-relaxed">{question}</p>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleAnswerQuestion(question)}
                        data-testid={`button-answer-${index}`}
                      >
                        Record Answer
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              {answeredQuestions.length > 0 && (
                <div className="space-y-4">
                  <Label className="text-base font-semibold">Answered Questions ({answeredQuestions.length})</Label>
                  <div className="space-y-4">
                    {answeredQuestions.map((qa, index) => (
                      <div key={index} className="p-5 bg-primary/5 rounded-md" data-testid={`answered-${index}`}>
                        <p className="text-xs font-medium text-muted-foreground mb-3">Q: {qa.question}</p>
                        <p className="text-base leading-relaxed">A: {qa.answer}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <Label htmlFor="conversation-notes" className="text-base font-medium">Additional Notes (Optional)</Label>
                <Textarea
                  id="conversation-notes"
                  data-testid="input-conversation-notes"
                  placeholder="Any additional details from the conversation..."
                  value={conversationNotes}
                  onChange={(e) => setConversationNotes(e.target.value)}
                  rows={4}
                  className="resize-none text-base"
                />
              </div>

              <div className="flex gap-4 pt-4">
                <Button
                  onClick={handleReviewConversation}
                  disabled={reviewConversationMutation.isPending || answeredQuestions.length === 0}
                  variant="outline"
                  className="flex-1"
                  data-testid="button-review"
                >
                  {reviewConversationMutation.isPending ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <MessageSquare className="h-4 w-4 mr-2" />
                  )}
                  Review & Get More Questions
                </Button>
                <Button
                  onClick={handleFinalizeConversation}
                  disabled={cleanConversationMutation.isPending}
                  className="flex-1"
                  data-testid="button-finalize"
                >
                  {cleanConversationMutation.isPending ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <FileText className="h-4 w-4 mr-2" />
                  )}
                  Finalize Conversation
                </Button>
              </div>
            </>
          )}

          {currentStep === "finalized" && cleanedConversation && (
            <>
              <div className="space-y-5">
                <Label className="text-base font-semibold">Finalized Conversation</Label>
                <div className="p-5 bg-muted/30 rounded-md max-h-80 overflow-y-auto">
                  <p className="text-base whitespace-pre-line leading-relaxed" data-testid="text-cleaned-conversation">
                    {cleanedConversation}
                  </p>
                </div>
                <div className="flex justify-end gap-4">
                  {isExtension && (
                    <Button
                      onClick={handleSendToTekmetric}
                      variant="default"
                      data-testid="button-send-to-tekmetric"
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Send to Tekmetric
                    </Button>
                  )}
                  <CopyButton
                    text={cleanedConversation}
                    label="Copy Conversation"
                    data-testid="button-copy-conversation"
                  />
                </div>
              </div>

              <Button
                onClick={handleRestart}
                variant="outline"
                className="w-full"
                data-testid="button-restart"
              >
                Start New Concern
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      {currentStep !== "initial" && currentStep !== "finalized" && (
        <Card>
          <CardContent className="p-4">
            <Button
              onClick={handleRestart}
              variant="ghost"
              className="w-full"
              data-testid="button-cancel"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Cancel and Start Over
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
