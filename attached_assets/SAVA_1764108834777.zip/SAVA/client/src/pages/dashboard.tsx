import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { AlertCircle, CheckCircle2, TrendingUp, Users, Download, Chrome } from "lucide-react";
import type { TrainingExample, ObjectionResponse } from "@shared/schema";

export default function Dashboard() {
  const { data: trainingExamples, isLoading: trainingLoading } = useQuery<TrainingExample[]>({
    queryKey: ["/api/training"],
  });

  const { data: objections, isLoading: objectionsLoading } = useQuery<ObjectionResponse[]>({
    queryKey: ["/api/objections"],
  });

  const stats = [
    {
      title: "Training Examples",
      value: trainingExamples?.length || 0,
      icon: CheckCircle2,
      description: "Active training data",
      color: "text-primary",
    },
    {
      title: "Objection Responses",
      value: objections?.filter(o => o.isActive).length || 0,
      icon: AlertCircle,
      description: "Ready to use",
      color: "text-chart-2",
    },
    {
      title: "Close Rate",
      value: "65%",
      icon: TrendingUp,
      description: "Average performance",
      color: "text-chart-3",
    },
    {
      title: "Active Advisors",
      value: "12",
      icon: Users,
      description: "Using the system",
      color: "text-chart-4",
    },
  ];

  if (trainingLoading || objectionsLoading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  const handleDownloadExtension = () => {
    window.open('/api/extension/download', '_blank');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight" data-testid="text-dashboard-title">
          Dashboard
        </h1>
        <p className="text-muted-foreground mt-2">
          Overview of your AI sales assistant performance and configuration
        </p>
      </div>

      {/* Chrome Extension Download Section */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-primary/10">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Chrome className="h-6 w-6 text-primary" />
            <div className="flex-1">
              <CardTitle className="text-xl">Chrome Extension</CardTitle>
              <CardDescription>Install the AI Sales Assistant for Tekmetric</CardDescription>
            </div>
            <Button 
              onClick={handleDownloadExtension} 
              data-testid="button-download-extension"
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Download Extension
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm">
              The Chrome extension integrates directly into Tekmetric, providing real-time AI-powered sales scripts
              and conversation guidance right in your side panel while working with customers.
            </p>
            <div className="bg-card p-4 rounded-md border">
              <p className="text-sm font-medium mb-3">Installation Instructions:</p>
              <ol className="text-sm space-y-2 ml-4 list-decimal text-muted-foreground">
                <li>Click the "Download Extension" button above to download the extension files</li>
                <li>Extract the ZIP file to a folder on your computer</li>
                <li>Open Chrome and navigate to <code className="px-1.5 py-0.5 bg-muted rounded text-xs">chrome://extensions</code></li>
                <li>Enable "Developer mode" using the toggle in the top right</li>
                <li>Click "Load unpacked" and select the extracted extension folder</li>
                <li>Navigate to Tekmetric and click the extension icon to open the side panel</li>
              </ol>
            </div>
            <div className="flex items-start gap-2 text-sm text-muted-foreground">
              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <p>The extension requires access to Tekmetric pages to extract customer and repair order data.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} data-testid={`card-stat-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold" data-testid={`text-stat-value-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                  {stat.value}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {stat.description}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Training Activity</CardTitle>
            <CardDescription>Latest additions to your script training</CardDescription>
          </CardHeader>
          <CardContent>
            {trainingExamples && trainingExamples.length > 0 ? (
              <div className="space-y-4">
                {trainingExamples.slice(0, 5).map((example) => (
                  <div key={example.id} className="flex items-start gap-3 pb-3 border-b last:border-0">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium capitalize">
                        {example.scriptType.replace(/_/g, ' ')} - {example.category}
                      </p>
                      <p className="text-sm text-muted-foreground truncate mt-1">
                        {example.content}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">
                No training examples yet. Start by adding approved approaches.
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Objection Handler Status</CardTitle>
            <CardDescription>Your prepared responses by category</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {['price', 'timing', 'trust'].map((type) => {
                const count = objections?.filter(
                  (o) => o.objectionType === type && o.isActive
                ).length || 0;
                return (
                  <div key={type} className="flex items-center justify-between">
                    <span className="text-sm font-medium capitalize">{type} Concerns</span>
                    <span className="text-sm text-muted-foreground">
                      {count} {count === 1 ? 'response' : 'responses'}
                    </span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
