import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Trash2, Plus } from "lucide-react";
import type { TrainingExample, InsertTrainingExample } from "@shared/schema";

const SCRIPT_TYPES = [
  { value: "opening", label: "Opening Script" },
  { value: "repair_priority", label: "Repair Priority" },
  { value: "closing", label: "Closing Script" },
];

export default function Training() {
  const { toast } = useToast();
  const [newExample, setNewExample] = useState<Partial<InsertTrainingExample>>({
    organizationId: "default-org",
    category: "approved",
    scriptType: "full_script",
    content: "",
    description: "",
  });

  const { data: examples, isLoading } = useQuery<TrainingExample[]>({
    queryKey: ["/api/training"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertTrainingExample) => {
      return apiRequest("POST", "/api/training", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training"] });
      setNewExample({
        organizationId: "default-org",
        category: "approved",
        scriptType: "full_script",
        content: "",
        description: "",
      });
      toast({
        title: "Success",
        description: "Training example added",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add training example",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/training/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training"] });
      toast({
        title: "Success",
        description: "Training example deleted",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExample.content) return;
    createMutation.mutate(newExample as InsertTrainingExample);
  };

  const approvedExamples = examples?.filter((e) => e.category === "approved") || [];
  const avoidExamples = examples?.filter((e) => e.category === "avoid") || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight" data-testid="text-training-title">
          Script Training
        </h1>
        <p className="text-muted-foreground mt-2">
          Train the AI with examples of approved approaches and things to avoid
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Add Training Example</CardTitle>
          <CardDescription>
            Provide examples to guide the AI's script generation
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={newExample.category}
                  onValueChange={(value) =>
                    setNewExample({ ...newExample, category: value })
                  }
                >
                  <SelectTrigger id="category" data-testid="select-category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="approved">Approved Approach</SelectItem>
                    <SelectItem value="avoid">Avoid This</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <input
                  id="description"
                  type="text"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  placeholder="Brief note about this example"
                  value={newExample.description || ""}
                  onChange={(e) =>
                    setNewExample({ ...newExample, description: e.target.value })
                  }
                  data-testid="input-description"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">Example Content</Label>
              <Textarea
                id="content"
                placeholder="Enter the script example here..."
                className="min-h-32"
                value={newExample.content}
                onChange={(e) =>
                  setNewExample({ ...newExample, content: e.target.value })
                }
                data-testid="textarea-content"
                required
              />
            </div>

            <Button type="submit" disabled={createMutation.isPending} data-testid="button-add-example">
              <Plus className="h-4 w-4 mr-2" />
              Add Example
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600 dark:text-green-400">
              Approved Approaches
            </CardTitle>
            <CardDescription>
              Examples of effective sales scripts ({approvedExamples.length})
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {approvedExamples.map((example) => (
                <div
                  key={example.id}
                  className="space-y-3 pb-6 border-b last:border-b-0 last:pb-0"
                  data-testid={`card-approved-${example.id}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      {example.description && (
                        <p className="text-sm font-medium text-muted-foreground">
                          {example.description}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteMutation.mutate(example.id)}
                      data-testid={`button-delete-${example.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="prose prose-sm max-w-none">
                    <p className="text-base leading-loose whitespace-pre-line">{example.content}</p>
                  </div>
                </div>
              ))}
              {approvedExamples.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No approved examples yet. Add some to guide the AI.
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-600 dark:text-red-400">
              Avoid These
            </CardTitle>
            <CardDescription>
              Examples to prevent in generated scripts ({avoidExamples.length})
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {avoidExamples.map((example) => (
                <div
                  key={example.id}
                  className="space-y-3 pb-6 border-b last:border-b-0 last:pb-0"
                  data-testid={`card-avoid-${example.id}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      {example.description && (
                        <p className="text-sm font-medium text-muted-foreground">
                          {example.description}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteMutation.mutate(example.id)}
                      data-testid={`button-delete-${example.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="prose prose-sm max-w-none">
                    <p className="text-base leading-loose whitespace-pre-line">{example.content}</p>
                  </div>
                </div>
              ))}
              {avoidExamples.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No avoid examples yet. Add patterns to prevent.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
