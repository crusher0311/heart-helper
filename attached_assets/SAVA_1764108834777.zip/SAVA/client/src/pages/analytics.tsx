import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, TrendingUp, Users, DollarSign } from "lucide-react";

export default function Analytics() {
  const metrics = [
    {
      title: "Scripts Generated",
      value: "847",
      change: "+12%",
      trend: "up",
      icon: BarChart3,
    },
    {
      title: "Avg Close Rate",
      value: "68%",
      change: "+8%",
      trend: "up",
      icon: TrendingUp,
    },
    {
      title: "Active Users",
      value: "12",
      change: "+2",
      trend: "up",
      icon: Users,
    },
    {
      title: "Revenue Impact",
      value: "$45.2K",
      change: "+15%",
      trend: "up",
      icon: DollarSign,
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight" data-testid="text-analytics-title">
          Analytics
        </h1>
        <p className="text-muted-foreground mt-2">
          Track performance and ROI of your AI sales assistant
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <Card key={metric.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{metric.title}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold">{metric.value}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  <span className="text-green-600 dark:text-green-400">
                    {metric.change}
                  </span>{" "}
                  from last month
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Coming Soon</CardTitle>
          <CardDescription>
            Detailed analytics and insights are currently in development
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>• Script usage by advisor</p>
            <p>• Close rate trends over time</p>
            <p>• Most effective script variations</p>
            <p>• Objection handling success rates</p>
            <p>• Revenue attribution by AI-assisted sales</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
