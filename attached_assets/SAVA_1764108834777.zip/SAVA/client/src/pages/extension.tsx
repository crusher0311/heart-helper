import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CopyButton } from "@/components/copy-button";
import { FeedbackControls } from "@/components/feedback-controls";
import { ConcernIntakePanel } from "@/components/concern-intake-panel";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Skeleton } from "@/components/ui/skeleton";
import { RefreshCw, AlertCircle, Sparkles, Plus, X, Phone, ThumbsUp, ThumbsDown } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import type { GeneratedScript, GenerateScriptResponse, ObjectionResponse, PriceShopperScript, ConversationHistory } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

// Incoming Caller Panel Component
interface IncomingCallerPanelProps {
  onConversationStart?: (data: {
    customerName: string;
    vehicleInfo: {
      year: string;
      make: string;
      model: string;
    };
    symptoms: string[];
  }) => void;
}

function IncomingCallerPanel({ onConversationStart }: IncomingCallerPanelProps) {
  const { toast } = useToast();
  const [callerName, setCallerName] = useState("");
  const [callerReferral, setCallerReferral] = useState("");
  const [callerSymptoms, setCallerSymptoms] = useState<string[]>([]);
  const [symptomInput, setSymptomInput] = useState("");
  const [callerVehicle, setCallerVehicle] = useState({ year: "", make: "", model: "" });
  const [conversationHistory, setConversationHistory] = useState<ConversationHistory[]>([]);
  const [currentAnswer, setCurrentAnswer] = useState("");
  const [hasStarted, setHasStarted] = useState(false);
  const [pendingQuestionIndex, setPendingQuestionIndex] = useState<number | null>(null);
  const [savedConversationId, setSavedConversationId] = useState<string | null>(null);
  const [hasBeenSaved, setHasBeenSaved] = useState(false);
  const [saveError, setSaveError] = useState(false);
  
  // Fetch organization settings for phone answer script
  const { data: orgData } = useQuery({
    queryKey: ["/api/organizations/current"],
    queryFn: async () => {
      const response = await fetch("/api/organizations/current");
      if (!response.ok) throw new Error("Failed to fetch organization");
      return await response.json();
    },
  });
  
  // Mutation for saving conversation to database
  const saveConversationMutation = useMutation({
    mutationFn: async (conversationData: {
      conversationType: "incoming_caller";
      customerName?: string;
      referralSource?: string;
      symptoms: string[];
      vehicleInfo?: { year: string; make: string; model: string };
      conversationHistory: ConversationHistory[];
    }) => {
      const response = await apiRequest("POST", "/api/conversations", conversationData);
      return await response.json();
    },
    onMutate: () => {
      setSaveError(false); // Clear error when retrying
    },
    onSuccess: (data) => {
      setSavedConversationId(data.id);
      setHasBeenSaved(true);
      setSaveError(false);
      toast({
        title: "Conversation Saved",
        description: "Ready to collect feedback",
      });
    },
    onError: (error) => {
      console.error("Failed to save conversation:", error);
      setHasBeenSaved(false);
      setSaveError(true);
      toast({
        title: "Save Failed",
        description: "Unable to save conversation. Please click retry below.",
        variant: "destructive",
      });
    },
  });

  // Mutation for generating next question (accepts payload to avoid stale state)
  const generateMutation = useMutation({
    mutationFn: async (payload: {
      customerName?: string;
      referralSource?: string;
      symptoms: string[];
      vehicleInfo?: { year: string; make: string; model: string };
      conversationHistory: ConversationHistory[];
    }) => {
      const response = await apiRequest("POST", "/api/scripts/price-shopper", payload);
      return await response.json() as PriceShopperScript;
    },
    onSuccess: (data, variables) => {
      // Update previous entry with objection detection result if it exists
      const updated = [...variables.conversationHistory];
      if (updated.length > 0 && data.objectionDetected) {
        updated[updated.length - 1] = {
          ...updated[updated.length - 1],
          objectionDetected: data.objectionDetected,
        };
      }
      
      // Check if previous entry had objection (after updating it)
      const previousHadObjection = updated.length > 0 && updated[updated.length - 1].objectionDetected;
      
      // Create placeholder entry for this question
      const newEntry: ConversationHistory = {
        question: data.currentQuestion,
        answer: undefined,
        isObjectionResponse: !!previousHadObjection,
      };
      
      // Append new placeholder and update state
      const result = [...updated, newEntry];
      setConversationHistory(result);
      setPendingQuestionIndex(result.length - 1);
      
      // If conversation is closing, save it immediately
      if (data.shouldClose && !hasBeenSaved) {
        saveConversationMutation.mutate({
          conversationType: "incoming_caller",
          customerName: variables.customerName,
          referralSource: variables.referralSource,
          symptoms: variables.symptoms,
          vehicleInfo: variables.vehicleInfo,
          conversationHistory: result, // Includes final closing prompt
        });
      }
    },
  });

  const handleAddSymptom = () => {
    if (symptomInput.trim() && !callerSymptoms.includes(symptomInput.trim())) {
      setCallerSymptoms([...callerSymptoms, symptomInput.trim()]);
      setSymptomInput("");
    }
  };
  
  const handleRemoveSymptom = (index: number) => {
    setCallerSymptoms(callerSymptoms.filter((_, i) => i !== index));
  };
  
  const handleStart = () => {
    setHasStarted(true);
    // Reset conversation state for new conversation
    setSavedConversationId(null);
    setHasBeenSaved(false);
    setSaveError(false);
    setConversationHistory([]);
    setPendingQuestionIndex(null);
    
    // Notify parent component about conversation start (for Sales Script tab)
    if (onConversationStart) {
      onConversationStart({
        customerName: callerName || "",
        vehicleInfo: {
          year: callerVehicle.year || "",
          make: callerVehicle.make || "",
          model: callerVehicle.model || "",
        },
        symptoms: callerSymptoms,
      });
    }
    
    // Build payload with current state
    const payload = {
      customerName: callerName || undefined,
      referralSource: callerReferral || undefined,
      symptoms: callerSymptoms,
      vehicleInfo: callerVehicle.year || callerVehicle.make || callerVehicle.model 
        ? callerVehicle 
        : undefined,
      conversationHistory: [],
    };
    
    generateMutation.mutate(payload);
  };
  
  const handleAnswerQuestion = () => {
    if (!generateMutation.data || pendingQuestionIndex === null) return;
    
    // Build updated history with the customer's answer
    const updatedHistory = [...conversationHistory];
    updatedHistory[pendingQuestionIndex] = {
      ...updatedHistory[pendingQuestionIndex],
      answer: currentAnswer || undefined,
    };
    
    // Update state with the new history
    setConversationHistory(updatedHistory);
    setCurrentAnswer("");
    
    // Build payload with updated history
    const payload = {
      customerName: callerName || undefined,
      referralSource: callerReferral || undefined,
      symptoms: callerSymptoms,
      vehicleInfo: callerVehicle.year || callerVehicle.make || callerVehicle.model 
        ? callerVehicle 
        : undefined,
      conversationHistory: updatedHistory,
    };
    
    // Generate next question (which will detect objection and update this entry in onSuccess)
    // Note: If shouldClose is true, the useEffect will handle saving
    generateMutation.mutate(payload);
  };
  
  const handleSkip = () => {
    if (!generateMutation.data || pendingQuestionIndex === null) return;
    
    // History already has answer: undefined for this entry
    const updatedHistory = [...conversationHistory];
    
    // Build payload with current history
    const payload = {
      customerName: callerName || undefined,
      referralSource: callerReferral || undefined,
      symptoms: callerSymptoms,
      vehicleInfo: callerVehicle.year || callerVehicle.make || callerVehicle.model 
        ? callerVehicle 
        : undefined,
      conversationHistory: updatedHistory,
    };
    
    generateMutation.mutate(payload);
  };

  const handleRetrySave = () => {
    saveConversationMutation.mutate({
      conversationType: "incoming_caller",
      customerName: callerName || undefined,
      referralSource: callerReferral || undefined,
      symptoms: callerSymptoms,
      vehicleInfo: callerVehicle.year || callerVehicle.make || callerVehicle.model 
        ? callerVehicle 
        : undefined,
      conversationHistory: conversationHistory,
    });
  };
  
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 pb-2 border-b">
        <Phone className="h-5 w-5 text-primary" />
        <h2 className="text-base font-semibold">Incoming Caller</h2>
      </div>
      
      {/* Phone Answer Script */}
      {orgData?.phoneAnswerScript && (
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Phone className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium text-primary">Phone Answer Script</p>
                <p className="text-sm leading-relaxed" data-testid="text-phone-answer-script">
                  {orgData.phoneAnswerScript}
                </p>
              </div>
              <CopyButton text={orgData.phoneAnswerScript} label="" />
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Form Section */}
      <Card>
        <CardContent className="p-4 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="caller-name" data-testid="label-caller-name">Customer Name</Label>
            <Input
              id="caller-name"
              data-testid="input-caller-name"
              value={callerName}
              onChange={(e) => setCallerName(e.target.value)}
              placeholder="Ask for their name..."
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="caller-referral" data-testid="label-caller-referral">How did they hear about us?</Label>
            <Input
              id="caller-referral"
              data-testid="input-caller-referral"
              value={callerReferral}
              onChange={(e) => setCallerReferral(e.target.value)}
              placeholder="Google, friend, etc..."
            />
          </div>
          
          <div className="space-y-2">
            <Label data-testid="label-symptoms">Symptoms / Issues</Label>
            <div className="flex gap-2">
              <Input
                data-testid="input-symptom"
                value={symptomInput}
                onChange={(e) => setSymptomInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSymptom();
                  }
                }}
                placeholder="Describe the issue..."
              />
              <Button
                type="button"
                size="icon"
                onClick={handleAddSymptom}
                data-testid="button-add-symptom"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            
            {callerSymptoms.length > 0 && (
              <div className="space-y-2 mt-2">
                {callerSymptoms.map((symptom, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between gap-2 p-2 bg-muted/30 rounded"
                    data-testid={`symptom-item-${index}`}
                  >
                    <span className="text-sm">{symptom}</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemoveSymptom(index)}
                      data-testid={`button-remove-symptom-${index}`}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div className="grid grid-cols-3 gap-2">
            <div className="space-y-1">
              <Label htmlFor="caller-year" className="text-xs">Year</Label>
              <Input
                id="caller-year"
                data-testid="input-caller-year"
                value={callerVehicle.year}
                onChange={(e) => setCallerVehicle({ ...callerVehicle, year: e.target.value })}
                placeholder="2018"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="caller-make" className="text-xs">Make</Label>
              <Input
                id="caller-make"
                data-testid="input-caller-make"
                value={callerVehicle.make}
                onChange={(e) => setCallerVehicle({ ...callerVehicle, make: e.target.value })}
                placeholder="Honda"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="caller-model" className="text-xs">Model</Label>
              <Input
                id="caller-model"
                data-testid="input-caller-model"
                value={callerVehicle.model}
                onChange={(e) => setCallerVehicle({ ...callerVehicle, model: e.target.value })}
                placeholder="Accord"
              />
            </div>
          </div>
          
          {!hasStarted && (
            <Button
              onClick={handleStart}
              className="w-full"
              data-testid="button-start-conversation"
            >
              <Phone className="h-4 w-4 mr-2" />
              Start Conversation
            </Button>
          )}
        </CardContent>
      </Card>
      
      {/* Conversation History */}
      {conversationHistory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Conversation Flow</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {conversationHistory.map((item, index) => {
              const isLastEntry = index === conversationHistory.length - 1;
              const isClosingStatement = isLastEntry && !item.answer && generateMutation.data?.shouldClose;
              
              return (
                <div key={index} className="space-y-1 pb-3 border-b last:border-0 last:pb-0">
                  <div className="flex items-start gap-2">
                    <p className="text-sm font-medium flex-1">
                      Q{index + 1}: {item.question}
                    </p>
                    {item.isObjectionResponse && (
                      <span className="text-xs bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 px-2 py-0.5 rounded">
                        Objection Response
                      </span>
                    )}
                  </div>
                  {item.answer && (
                    <div className="pl-4 space-y-1">
                      <p className="text-sm text-muted-foreground">→ {item.answer}</p>
                      {item.objectionDetected && (
                        <p className="text-xs text-amber-600 dark:text-amber-400">
                          ⚠️ {item.objectionDetected.charAt(0).toUpperCase() + item.objectionDetected.slice(1)} objection detected
                        </p>
                      )}
                    </div>
                  )}
                  {!item.answer && !isClosingStatement && (
                    <p className="text-xs text-muted-foreground pl-4 italic">Skipped</p>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}
      
      {/* Current Question */}
      {generateMutation.isPending && (
        <Card>
          <CardContent className="py-12">
            <div className="flex flex-col items-center gap-4 text-center">
              <div className="relative">
                <Sparkles className="h-10 w-10 text-primary animate-pulse" />
                <div className="absolute inset-0 h-10 w-10 text-primary/20 animate-ping">
                  <Sparkles className="h-10 w-10" />
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-base font-semibold">Generating Next Question</p>
                <p className="text-sm text-muted-foreground max-w-xs">
                  AI is analyzing the conversation...
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {generateMutation.isError && (
        <Card>
          <CardContent className="py-8">
            <div className="flex items-center gap-2 text-sm text-destructive justify-center">
              <AlertCircle className="h-4 w-4" />
              <span>Error: {generateMutation.error instanceof Error ? generateMutation.error.message : 'Unable to generate question'}</span>
            </div>
          </CardContent>
        </Card>
      )}
      
      {generateMutation.data && !generateMutation.isPending && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Phone className="h-4 w-4" />
              {generateMutation.data.shouldClose ? "Close the Call" : "Ask This Question"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {generateMutation.data.greeting && conversationHistory.length === 0 && (
              <div className="p-3 bg-primary/5 rounded">
                <p className="text-sm font-medium mb-1">Greeting</p>
                <p className="text-sm text-muted-foreground">{generateMutation.data.greeting}</p>
              </div>
            )}
            
            {generateMutation.data.objectionDetected && (
              <div className="p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded">
                <p className="text-sm font-medium text-amber-900 dark:text-amber-100">
                  ⚠️ {generateMutation.data.objectionDetected.charAt(0).toUpperCase() + generateMutation.data.objectionDetected.slice(1)} Objection Detected
                </p>
                <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                  Use this scripted response to handle the objection
                </p>
              </div>
            )}
            
            <div className="space-y-3">
              <div className="p-4 bg-muted/30 rounded-lg">
                <p className="text-base leading-loose">{generateMutation.data.currentQuestion}</p>
              </div>
              
              {!generateMutation.data.shouldClose && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="answer-input">Customer's Response</Label>
                    <Input
                      id="answer-input"
                      data-testid="input-customer-answer"
                      value={currentAnswer}
                      onChange={(e) => setCurrentAnswer(e.target.value)}
                      placeholder="Type what they said..."
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && currentAnswer.trim()) {
                          handleAnswerQuestion();
                        }
                      }}
                    />
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      onClick={handleAnswerQuestion}
                      disabled={!currentAnswer.trim()}
                      className="flex-1"
                      data-testid="button-answer-question"
                    >
                      Next Question
                    </Button>
                    <Button
                      onClick={handleSkip}
                      variant="outline"
                      data-testid="button-skip-question"
                    >
                      Skip
                    </Button>
                  </div>
                </>
              )}
              
              {generateMutation.data.shouldClose && generateMutation.data.appointmentClose && (
                <>
                  <div className="p-3 bg-primary/5 rounded border border-primary/20">
                    <p className="text-sm font-medium mb-2">Appointment Close:</p>
                    <p className="text-sm text-muted-foreground">{generateMutation.data.appointmentClose}</p>
                    <div className="flex justify-end mt-3">
                      <CopyButton 
                        text={generateMutation.data.appointmentClose}
                        data-testid="button-copy-close"
                      />
                    </div>
                  </div>
                  
                  {/* Retry save button if save failed or in progress */}
                  {(saveError || saveConversationMutation.isPending) && !hasBeenSaved && (
                    <div className="p-3 bg-destructive/10 rounded border border-destructive/20">
                      <p className="text-sm font-medium text-destructive mb-2">
                        {saveConversationMutation.isPending ? "Saving conversation..." : "Conversation not saved!"}
                      </p>
                      <Button 
                        onClick={handleRetrySave}
                        variant="destructive"
                        className="w-full"
                        disabled={saveConversationMutation.isPending}
                        data-testid="button-retry-save"
                      >
                        {saveConversationMutation.isPending ? "Saving..." : "Retry Save"}
                      </Button>
                    </div>
                  )}
                  
                  {/* Feedback controls after successful save */}
                  {savedConversationId && hasBeenSaved && (
                    <FeedbackControls
                      targetId={savedConversationId}
                      targetType="conversation"
                    />
                  )}
                </>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default function Extension() {
  const [activeTab, setActiveTab] = useState<string>(() => {
    return localStorage.getItem('extension-active-tab') || 'sales-script';
  });

  useEffect(() => {
    const isExtension = typeof chrome !== 'undefined' && chrome.runtime;
    
    if (isExtension) {
      const messageListener = (message: any) => {
        if (message.type === 'SWITCH_TO_CONCERN_INTAKE') {
          console.log('[Extension Page] Switching to concern intake tab');
          setActiveTab('concern-intake');
          localStorage.setItem('extension-active-tab', 'concern-intake');
        }
      };
      
      chrome.runtime.onMessage.addListener(messageListener);
      
      return () => {
        chrome.runtime.onMessage.removeListener(messageListener);
      };
    }
  }, []);
  
  useEffect(() => {
    localStorage.setItem('extension-active-tab', activeTab);
  }, [activeTab]);
  
  const [roNumber, setRoNumber] = useState("");
  const [isExtensionMode, setIsExtensionMode] = useState(false);
  
  // Start with empty customer data - will be populated from Tekmetric
  const [customerData, setCustomerData] = useState({
    customerName: "",
    vehicleInfo: {
      year: "",
      make: "",
      model: "",
      mileage: "",
    },
    serviceWriter: "",
    technician: "",
    concerns: [] as string[],
    repairOrders: [] as Array<{
      service: string;
      priority: "critical" | "recommended" | "optional";
      price: number;
      description: string;
    }>,
    grandTotal: undefined as number | undefined,
    subtotal: undefined as number | undefined,
    tax: undefined as number | undefined,
  });

  // Listen for messages from Chrome extension
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      console.log('[Extension Page] Received message:', event.data);
      
      if (event.data.type === 'TEKMETRIC_DATA') {
        const tekmetricData = event.data.data;
        console.log('[Extension Page] ====== TEKMETRIC DATA RECEIVED ======');
        console.log('[Extension Page] Full data object:', JSON.stringify(tekmetricData, null, 2));
        console.log('[Extension Page] customerName:', tekmetricData?.customerName);
        console.log('[Extension Page] vehicleInfo:', tekmetricData?.vehicleInfo);
        console.log('[Extension Page] roNumber:', tekmetricData?.roNumber);
        console.log('[Extension Page] serviceWriter:', tekmetricData?.serviceWriter);
        console.log('[Extension Page] technician:', tekmetricData?.technician);
        console.log('[Extension Page] ====================================');
        
        setIsExtensionMode(true);
        
        // Update RO number
        if (tekmetricData?.roNumber) {
          console.log('[Extension Page] ✅ Updating RO number to:', tekmetricData.roNumber);
          setRoNumber(tekmetricData.roNumber);
        }
        
        // Update customer data from Tekmetric
        if (tekmetricData?.customerName || tekmetricData?.vehicleInfo) {
          // Handle vehicleInfo - could be string OR object from backend
          let vehicleInfo;
          if (tekmetricData.vehicleInfo) {
            if (typeof tekmetricData.vehicleInfo === 'string') {
              // String format: parse it
              vehicleInfo = parseVehicleInfo(tekmetricData.vehicleInfo, tekmetricData.mileage);
            } else {
              // Object format: use directly, add mileage if missing
              vehicleInfo = {
                year: tekmetricData.vehicleInfo.year || "",
                make: tekmetricData.vehicleInfo.make || "",
                model: tekmetricData.vehicleInfo.model || "",
                mileage: tekmetricData.vehicleInfo.mileage?.toString() || tekmetricData.mileage || ""
              };
            }
          } else {
            vehicleInfo = { year: "", make: "", model: "", mileage: tekmetricData.mileage || "" };
          }
          
          console.log('[Extension Page] ✅ Updating customer data with:', {
            customerName: tekmetricData.customerName,
            vehicleInfo,
            extractedMileage: tekmetricData.mileage,
            serviceWriter: tekmetricData.serviceWriter,
            technician: tekmetricData.technician,
            concerns: tekmetricData.concerns
          });
          
          setCustomerData({
            customerName: tekmetricData.customerName || "Unknown Customer",
            vehicleInfo,
            serviceWriter: tekmetricData.serviceWriter || "",
            technician: tekmetricData.technician || "",
            concerns: tekmetricData.concerns || [],
            repairOrders: tekmetricData.repairOrders || [],
            grandTotal: tekmetricData.grandTotal,
            subtotal: tekmetricData.subtotal,
            tax: tekmetricData.tax,
          });
        } else {
          console.log('[Extension Page] ❌ No customer name or vehicle info in data - skipping update');
        }
      }
    };

    window.addEventListener('message', handleMessage);
    
    // Request initial data from extension
    const requestData = () => {
      console.log('[Extension Page] Requesting Tekmetric data from parent');
      window.parent.postMessage({ type: 'REQUEST_TEKMETRIC_DATA' }, '*');
    };
    
    requestData();
    
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  // Handler for when Incoming Caller conversation starts - shares data with Sales Script tab
  const handleCallerConversationStart = (data: {
    customerName: string;
    vehicleInfo: {
      year: string;
      make: string;
      model: string;
    };
    symptoms: string[];
  }) => {
    // Update customerData for Sales Script generation
    setCustomerData({
      customerName: data.customerName,
      vehicleInfo: {
        year: data.vehicleInfo.year,
        make: data.vehicleInfo.make,
        model: data.vehicleInfo.model,
        mileage: "",
      },
      serviceWriter: "",
      technician: "",
      concerns: data.symptoms,
      repairOrders: [],
      grandTotal: 0,
      subtotal: 0,
      tax: 0,
    });
    
    // Generate RO number if not already set
    if (!roNumber) {
      setRoNumber(`CALLER-${Date.now()}`);
    }
  };

  const parseVehicleInfo = (vehicleText: string, extractedMileage?: string) => {
    // Parse vehicle string like "2011 Honda CR-Z EX - Estimate"
    // First, check if it contains a dash separator for additional info
    const dashIndex = vehicleText.indexOf(' - ');
    const mainPart = dashIndex > 0 ? vehicleText.substring(0, dashIndex).trim() : vehicleText.trim();
    
    // Split the main part and extract year, make, model
    const parts = mainPart.split(' ').filter(p => p);
    
    return {
      year: parts[0] || "",
      make: parts[1] || "",
      model: parts.slice(2).join(' ') || "",
      mileage: extractedMileage || "Unknown",
    };
  };

  const { data: objections } = useQuery<ObjectionResponse[]>({
    queryKey: ["/api/objections"],
  });

  const { data: scriptResponse, isLoading: scriptLoading, error, refetch } = useQuery<GenerateScriptResponse>({
    queryKey: ["/api/scripts/generate", roNumber, customerData.customerName, customerData.vehicleInfo],
    queryFn: async () => {
      console.log('[SCRIPT QUERY] Starting query...');
      // Ensure vehicleInfo is an object
      const vehicleInfoObj = typeof customerData.vehicleInfo === 'string'
        ? parseVehicleInfo(customerData.vehicleInfo)
        : customerData.vehicleInfo;
      
      console.log('[Extension Page] Generating script with data:', {
        customerName: customerData.customerName,
        vehicleInfo: vehicleInfoObj,
        vehicleInfoType: typeof vehicleInfoObj,
        repairOrders: customerData.repairOrders,
      });
      console.log('[Extension Page] vehicleInfoObj details:', vehicleInfoObj);
      console.log('[Extension Page] RAW repairOrders count:', customerData.repairOrders?.length || 0);
      console.log('[Extension Page] RAW repairOrders:', customerData.repairOrders);
      
      // Clean up repair orders - remove duplicates and junk
      const cleanOrders = customerData.repairOrders
        .filter((order, index, self) => {
          const service = order.service.trim();
          
          // Skip empty or very short (allow 5+ characters for valid short services like "DEGREASE", "ALIGNMENT")
          if (!service || service.length < 5) return false;
          
          // Skip obvious junk patterns
          if (service.includes('LaborTechnicianHours')) return false;
          if (service.includes('PartQtyCost')) return false;
          if (service.startsWith('GP%')) return false;
          if (service.startsWith('Subtotal')) return false;
          if (service.includes('All 1 Received')) return false;
          if (service.includes('All 4 Received')) return false;
          if (/^[\d.]+$/.test(service)) return false; // Just numbers
          
          // Keep only unique service names (case insensitive)
          const firstIndex = self.findIndex(o => 
            o.service.trim().toLowerCase() === service.toLowerCase()
          );
          return index === firstIndex;
        })
        .slice(0, 10); // Limit to 10 services max
      
      console.log('[Extension Page] After filter - cleanOrders count:', cleanOrders.length);
      console.log('[Extension Page] After filter - cleanOrders:', cleanOrders);
      
      // Ensure we have at least one repair order
      const ordersToSend = cleanOrders.length > 0 
        ? cleanOrders 
        : [{
            service: "General inspection and recommendations",
            priority: "recommended" as const,
            price: 0,
            description: "Awaiting service details from Tekmetric"
          }];
      
      console.log('[Extension Page] Cleaned orders:', ordersToSend);
      
      const response = await apiRequest("POST", "/api/scripts/generate", {
        organizationId: "default-org",
        customerName: customerData.customerName,
        vehicleInfo: vehicleInfoObj,
        repairOrders: ordersToSend,
        grandTotal: customerData.grandTotal,
        subtotal: customerData.subtotal,
        tax: customerData.tax,
        roNumber, // Include roNumber for backend
      });
      
      // Parse the JSON from the Response object
      const data = await response.json();
      console.log('[SCRIPT QUERY] Response received:', response);
      console.log('[SCRIPT QUERY] Parsed data:', data);
      console.log('[SCRIPT QUERY] Script content:', data?.script);
      console.log('[SCRIPT QUERY] Opening content:', data?.opening);
      console.log('[SCRIPT QUERY] Script ID:', data?.scriptId);
      return data;
    },
    enabled: !!roNumber && !!customerData.customerName, // Auto-generate when data is available
  });

  // Use scriptResponse directly - no need for separate state or derived object

  // Debug: Log when script data changes
  useEffect(() => {
    console.log('[SCRIPT STATE] Script data updated:', scriptResponse);
    console.log('[SCRIPT STATE] isLoading:', scriptLoading);
    console.log('[SCRIPT STATE] error:', error);
  }, [scriptResponse, scriptLoading, error]);

  const handleRefresh = () => {
    refetch();
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "destructive";
      case "recommended":
        return "default";
      case "optional":
        return "secondary";
      default:
        return "default";
    }
  };

  const getObjectionsByType = (type: string) => {
    return objections?.filter((o) => o.objectionType === type && o.isActive) || [];
  };

  if (scriptLoading && !customerData.customerName) {
    return (
      <div className="max-w-md mx-auto p-6">
        <Card>
          <CardContent className="py-16">
            <div className="flex flex-col items-center gap-4 text-center">
              <div className="relative">
                <Sparkles className="h-12 w-12 text-primary animate-pulse" />
                <div className="absolute inset-0 h-12 w-12 text-primary/20 animate-ping">
                  <Sparkles className="h-12 w-12" />
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-lg font-semibold">Loading Extension</p>
                <p className="text-sm text-muted-foreground max-w-sm">
                  Connecting to Tekmetric and preparing your AI assistant...
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Check if we have customer data
  const hasCustomerData = customerData.customerName && customerData.repairOrders.length > 0;

  return (
    <div className="h-screen flex flex-col">
      {/* Mode Tabs at Top */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-col h-full">
        <TabsList className="grid w-full grid-cols-3 rounded-none border-b">
          <Tooltip>
            <TooltipTrigger asChild>
              <TabsTrigger value="sales-script" data-testid="tab-sales-script" className="text-xl">
                ✨
              </TabsTrigger>
            </TooltipTrigger>
            <TooltipContent>
              <p>Sales Script</p>
            </TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <TabsTrigger value="incoming-caller" data-testid="tab-incoming-caller" className="text-xl">
                📞
              </TabsTrigger>
            </TooltipTrigger>
            <TooltipContent>
              <p>Incoming Caller</p>
            </TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <TabsTrigger value="concern-intake" data-testid="tab-concern-intake" className="text-xl">
                🤔
              </TabsTrigger>
            </TooltipTrigger>
            <TooltipContent>
              <p>Concern Intake</p>
            </TooltipContent>
          </Tooltip>
        </TabsList>

        {/* Header with RO info */}
        <div className="flex items-center justify-between px-3 py-2 border-b bg-muted/30">
          <div className="flex-1 min-w-0">
            <Tooltip>
              <TooltipTrigger asChild>
                <h1 className="text-sm font-semibold truncate cursor-help">SAVA by MOS</h1>
              </TooltipTrigger>
              <TooltipContent>
                <p>Service Advisor Virtual Assistant</p>
              </TooltipContent>
            </Tooltip>
            {roNumber && <p className="text-xs text-muted-foreground">RO: {roNumber}</p>}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleRefresh}
            data-testid="button-refresh"
            className="flex-shrink-0"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>

        <TabsContent value="sales-script" className="flex-1 overflow-y-auto p-3 space-y-3 mt-0">
          {/* Show customer context only if we have data */}
          {hasCustomerData && (
            <div data-testid="card-customer-context" className="space-y-2">
              <h3 className="text-base font-semibold">{customerData.customerName}</h3>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>
                  {customerData.vehicleInfo.year} {customerData.vehicleInfo.make}{" "}
                  {customerData.vehicleInfo.model}
                </span>
                <span className="text-xs">•</span>
                <span>{customerData.vehicleInfo.mileage} mi</span>
              </div>
            </div>
          )}

          {/* Script Generator */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Sales Script</h2>
          {scriptResponse && (
            <Button 
              variant="ghost" 
              size="sm"
              onClick={handleRefresh}
              data-testid="button-refresh-script"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
          )}
        </div>

        {scriptLoading ? (
          <Card>
            <CardContent className="py-12">
              <div className="flex flex-col items-center gap-4 text-center">
                <div className="relative">
                  <Sparkles className="h-10 w-10 text-primary animate-pulse" />
                  <div className="absolute inset-0 h-10 w-10 text-primary/20 animate-ping">
                    <Sparkles className="h-10 w-10" />
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="text-base font-semibold">Generating Your Script</p>
                  <p className="text-sm text-muted-foreground max-w-xs">
                    AI is crafting a personalized sales script based on customer data...
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : error ? (
          <Card>
            <CardContent className="py-8">
              <div className="flex items-center gap-2 text-sm text-destructive justify-center">
                <AlertCircle className="h-4 w-4" />
                <span>Error: {error instanceof Error ? error.message : 'Unable to generate script'}</span>
              </div>
            </CardContent>
          </Card>
        ) : scriptResponse ? (
          <div className="space-y-6">
            <div className="prose prose-sm max-w-none">
              <p className="text-base leading-loose whitespace-pre-line" data-testid="text-sales-script">
                {scriptResponse.script || `${scriptResponse.opening || ''}\n\n${scriptResponse.repairPriorities?.map(rp => rp.benefit).join('\n\n') || ''}\n\n${scriptResponse.closing || ''}`}
              </p>
            </div>
            <div className="flex justify-end pt-2 border-t">
              <CopyButton 
                text={scriptResponse.script || `${scriptResponse.opening || ''}\n\n${scriptResponse.repairPriorities?.map(rp => rp.benefit).join('\n\n') || ''}\n\n${scriptResponse.closing || ''}`}
                data-testid="button-copy-script"
              />
            </div>
            
            {/* Feedback controls for sales script */}
            {scriptResponse.scriptId && (
              <FeedbackControls
                targetId={scriptResponse.scriptId}
                targetType="sales-script"
              />
            )}
          </div>
        ) : !hasCustomerData ? (
          <Card>
            <CardContent className="py-12">
              <div className="flex flex-col items-center gap-4 text-center">
                <AlertCircle className="h-12 w-12 text-muted-foreground" />
                <div className="space-y-2">
                  <p className="text-base font-semibold">No Repair Order Loaded</p>
                  <p className="text-sm text-muted-foreground max-w-xs">
                    Please open a repair order in Tekmetric to generate a personalized sales script.
                  </p>
                </div>
                <div className="mt-2 p-3 bg-muted/30 rounded-md">
                  <p className="text-xs text-muted-foreground">
                    Navigate to a repair order page in Tekmetric, then refresh this panel.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="py-8">
              <div className="flex flex-col items-center gap-2 text-sm text-muted-foreground justify-center">
                <AlertCircle className="h-4 w-4" />
                <span>Waiting for customer data...</span>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Objection Handler - Collapsible */}
      <Accordion type="single" collapsible className="w-full" data-testid="card-objection-handler">
        <AccordionItem value="objections" className="border rounded-lg px-4">
          <AccordionTrigger className="text-base font-semibold hover:no-underline py-3">
            Quick Objection Responses
          </AccordionTrigger>
          <AccordionContent className="pb-4">
            <Tabs defaultValue="price" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-3">
                <TabsTrigger value="price" className="text-xs" data-testid="tab-price">
                  Price
                </TabsTrigger>
                <TabsTrigger value="timing" className="text-xs" data-testid="tab-timing">
                  Timing
                </TabsTrigger>
                <TabsTrigger value="trust" className="text-xs" data-testid="tab-trust">
                  Trust
                </TabsTrigger>
              </TabsList>

              <TabsContent value="price" className="space-y-3 mt-2">
                {getObjectionsByType("price").slice(0, 2).map((objection, index) => (
                  <div key={objection.id} className="space-y-1.5 p-3 bg-muted/30 rounded">
                    <p className="text-sm leading-relaxed">{objection.response}</p>
                    <div className="flex justify-end">
                      <CopyButton text={objection.response} label="" />
                    </div>
                  </div>
                ))}
                {getObjectionsByType("price").length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-2">
                    No responses available
                  </p>
                )}
              </TabsContent>

              <TabsContent value="timing" className="space-y-3 mt-2">
                {getObjectionsByType("timing").slice(0, 2).map((objection, index) => (
                  <div key={objection.id} className="space-y-1.5 p-3 bg-muted/30 rounded">
                    <p className="text-sm leading-relaxed">{objection.response}</p>
                    <div className="flex justify-end">
                      <CopyButton text={objection.response} label="" />
                    </div>
                  </div>
                ))}
                {getObjectionsByType("timing").length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-2">
                    No responses available
                  </p>
                )}
              </TabsContent>

              <TabsContent value="trust" className="space-y-3 mt-2">
                {getObjectionsByType("trust").slice(0, 2).map((objection, index) => (
                  <div key={objection.id} className="space-y-1.5 p-3 bg-muted/30 rounded">
                    <p className="text-sm leading-relaxed">{objection.response}</p>
                    <div className="flex justify-end">
                      <CopyButton text={objection.response} label="" />
                    </div>
                  </div>
                ))}
                {getObjectionsByType("trust").length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-2">
                    No responses available
                  </p>
                )}
              </TabsContent>
            </Tabs>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
        </TabsContent>

        <TabsContent value="incoming-caller" className="flex-1 overflow-y-auto p-3 mt-0">
          <IncomingCallerPanel onConversationStart={handleCallerConversationStart} />
        </TabsContent>

        <TabsContent value="concern-intake" className="flex-1 overflow-y-auto p-3 mt-0">
          <ConcernIntakePanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}
