import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Trash2, Plus, GripVertical } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { ObjectionResponse, InsertObjectionResponse } from "@shared/schema";

export default function Objections() {
  const { toast } = useToast();
  const [newResponse, setNewResponse] = useState<Partial<InsertObjectionResponse>>({
    organizationId: "default-org",
    objectionType: "price",
    response: "",
    isActive: true,
    sortOrder: 0,
  });

  const { data: objections, isLoading } = useQuery<ObjectionResponse[]>({
    queryKey: ["/api/objections"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertObjectionResponse) => {
      return apiRequest("POST", "/api/objections", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/objections"] });
      setNewResponse({
        organizationId: "default-org",
        objectionType: "price",
        response: "",
        isActive: true,
        sortOrder: 0,
      });
      toast({
        title: "Success",
        description: "Objection response added",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add objection response",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/objections/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/objections"] });
      toast({
        title: "Success",
        description: "Objection response deleted",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newResponse.response) return;
    createMutation.mutate(newResponse as InsertObjectionResponse);
  };

  const getObjectionsByType = (type: string) => {
    return objections?.filter((o) => o.objectionType === type && o.isActive) || [];
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight" data-testid="text-objections-title">
          Objection Library
        </h1>
        <p className="text-muted-foreground mt-2">
          Manage pre-written responses for common customer objections
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Add Objection Response</CardTitle>
          <CardDescription>
            Create effective responses to help advisors handle customer concerns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="objectionType">Objection Type</Label>
              <Select
                value={newResponse.objectionType}
                onValueChange={(value) =>
                  setNewResponse({ ...newResponse, objectionType: value })
                }
              >
                <SelectTrigger id="objectionType" data-testid="select-objection-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="price">Price Concerns</SelectItem>
                  <SelectItem value="timing">Timing Issues</SelectItem>
                  <SelectItem value="trust">Trust Building</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="response">Response</Label>
              <Textarea
                id="response"
                placeholder="Enter the objection response here..."
                className="min-h-32"
                value={newResponse.response}
                onChange={(e) =>
                  setNewResponse({ ...newResponse, response: e.target.value })
                }
                data-testid="textarea-response"
                required
              />
              <p className="text-xs text-muted-foreground">
                Write a natural, conversational response that addresses the customer's concern
              </p>
            </div>

            <Button type="submit" disabled={createMutation.isPending} data-testid="button-add-response">
              <Plus className="h-4 w-4 mr-2" />
              Add Response
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Objection Responses</CardTitle>
          <CardDescription>
            Organized by objection type for quick access
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="price" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="price" data-testid="tab-price">
                Price Concerns
              </TabsTrigger>
              <TabsTrigger value="timing" data-testid="tab-timing">
                Timing Issues
              </TabsTrigger>
              <TabsTrigger value="trust" data-testid="tab-trust">
                Trust Building
              </TabsTrigger>
            </TabsList>

            <TabsContent value="price" className="space-y-4 mt-4">
              {getObjectionsByType("price").length > 0 ? (
                getObjectionsByType("price").map((objection, index) => (
                  <div
                    key={objection.id}
                    className="p-4 border rounded-lg flex items-start gap-3"
                    data-testid={`card-price-${objection.id}`}
                  >
                    <GripVertical className="h-5 w-5 text-muted-foreground mt-1 cursor-move" />
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <span className="text-xs font-semibold text-muted-foreground">
                          Response #{index + 1}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteMutation.mutate(objection.id)}
                          data-testid={`button-delete-${objection.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-sm leading-relaxed mt-2">{objection.response}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No price objection responses yet. Add some to help advisors.
                </p>
              )}
            </TabsContent>

            <TabsContent value="timing" className="space-y-4 mt-4">
              {getObjectionsByType("timing").length > 0 ? (
                getObjectionsByType("timing").map((objection, index) => (
                  <div
                    key={objection.id}
                    className="p-4 border rounded-lg flex items-start gap-3"
                    data-testid={`card-timing-${objection.id}`}
                  >
                    <GripVertical className="h-5 w-5 text-muted-foreground mt-1 cursor-move" />
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <span className="text-xs font-semibold text-muted-foreground">
                          Response #{index + 1}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteMutation.mutate(objection.id)}
                          data-testid={`button-delete-${objection.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-sm leading-relaxed mt-2">{objection.response}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No timing objection responses yet. Add some to help advisors.
                </p>
              )}
            </TabsContent>

            <TabsContent value="trust" className="space-y-4 mt-4">
              {getObjectionsByType("trust").length > 0 ? (
                getObjectionsByType("trust").map((objection, index) => (
                  <div
                    key={objection.id}
                    className="p-4 border rounded-lg flex items-start gap-3"
                    data-testid={`card-trust-${objection.id}`}
                  >
                    <GripVertical className="h-5 w-5 text-muted-foreground mt-1 cursor-move" />
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <span className="text-xs font-semibold text-muted-foreground">
                          Response #{index + 1}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteMutation.mutate(objection.id)}
                          data-testid={`button-delete-${objection.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-sm leading-relaxed mt-2">{objection.response}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No trust objection responses yet. Add some to help advisors.
                </p>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
