import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Settings() {
  const { toast } = useToast();
  const [phoneAnswerScript, setPhoneAnswerScript] = useState("");

  // Fetch organization settings
  const { data: orgData, isLoading } = useQuery({
    queryKey: ["/api/organizations/current"],
    queryFn: async () => {
      const response = await fetch("/api/organizations/current");
      if (!response.ok) throw new Error("Failed to fetch organization");
      return await response.json();
    },
  });

  // Update the local state when data loads
  useEffect(() => {
    if (orgData?.phoneAnswerScript) {
      setPhoneAnswerScript(orgData.phoneAnswerScript);
    }
  }, [orgData]);

  // Save organization settings mutation
  const saveSettingsMutation = useMutation({
    mutationFn: async (data: { phoneAnswerScript: string }) => {
      const response = await apiRequest("PATCH", "/api/organizations/current", data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations/current"] });
      toast({
        title: "Settings Saved",
        description: "Your changes have been saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Save Failed",
        description: `Failed to save settings: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleSavePhoneScript = () => {
    saveSettingsMutation.mutate({ phoneAnswerScript });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight" data-testid="text-settings-title">
          Shop Settings
        </h1>
        <p className="text-muted-foreground mt-2">
          Configure your organization and integration settings
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Organization Details</CardTitle>
          <CardDescription>
            Basic information about your shop
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="shopName">Shop Name</Label>
            <Input
              id="shopName"
              placeholder="Enter shop name"
              defaultValue="Default Organization"
              data-testid="input-shop-name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              placeholder="City, State"
              data-testid="input-location"
            />
          </div>
          <Button data-testid="button-save-settings">Save Changes</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Incoming Caller Settings</CardTitle>
          <CardDescription>
            Configure the phone answer script for incoming calls
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="phoneAnswerScript">Phone Answer Script</Label>
            <Textarea
              id="phoneAnswerScript"
              placeholder="e.g., Thank you for calling (Shop Name), this is (Name), how may I help you?"
              value={phoneAnswerScript}
              onChange={(e) => setPhoneAnswerScript(e.target.value)}
              rows={3}
              data-testid="textarea-phone-answer-script"
            />
            <p className="text-xs text-muted-foreground">
              This script will be displayed at the top of the Incoming Caller panel. Use (Shop Name) and (Name) as placeholders.
            </p>
          </div>
          <Button 
            onClick={handleSavePhoneScript}
            disabled={saveSettingsMutation.isPending}
            data-testid="button-save-phone-script"
          >
            {saveSettingsMutation.isPending ? "Saving..." : "Save Script"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tekmetric Integration</CardTitle>
          <CardDescription>
            Configure your Tekmetric API connection
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="apiKey">API Key</Label>
            <Input
              id="apiKey"
              type="password"
              placeholder="Enter Tekmetric API key"
              data-testid="input-api-key"
            />
            <p className="text-xs text-muted-foreground">
              Your API key is securely stored and encrypted
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="shopId">Shop ID</Label>
            <Input
              id="shopId"
              placeholder="Enter Tekmetric Shop ID"
              data-testid="input-shop-id"
            />
          </div>
          <Button data-testid="button-test-connection">Test Connection</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>OpenAI Configuration</CardTitle>
          <CardDescription>
            AI model settings for script generation
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="model">Model</Label>
            <Input
              id="model"
              placeholder="gpt-5"
              defaultValue="gpt-5"
              data-testid="input-model"
              disabled
            />
            <p className="text-xs text-muted-foreground">
              Using the latest GPT-5 model for best results
            </p>
          </div>
          <p className="text-sm text-muted-foreground">
            API key is configured via environment variables for security
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
